package com.nationalgrid.automation.nysl.base;

import static com.nationalgrid.automation.nysl.base.BrowserFactory.driver;

import java.io.File;
import java.io.IOException;
import java.util.Calendar;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class CustomReporter {
	
	public static ExtentReports extent;
	public static ExtentTest test;
	public static String resultLocation;
	public static String timeStamp;
	private static Logger logger = Logger.getLogger(CustomReporter.class);

	private static String fGetRandomNumUsingTime() {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(calendar.getTime());
		int month = Calendar.MONTH;
		int day = Calendar.DAY_OF_MONTH;
		int hours = calendar.get(Calendar.HOUR_OF_DAY);
		int minutes = calendar.get(Calendar.MINUTE);
		int seconds = calendar.get(Calendar.SECOND);
		String Rand = Integer.toString(month) + Integer.toString(day) + Integer.toString(hours)
				+ Integer.toString(minutes) + Integer.toString(seconds);
		return Rand;
	}

	public static void flagResult(String Status, String Step, String Decripion, String ScreenShot) throws Exception {
		if (ScreenShot.equalsIgnoreCase("yes")) {
			String screenshotName = "img" + fGetRandomNumUsingTime() + ".jpg";
			File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			try {
				FileUtils.copyFile(scrFile, new File(resultLocation + "\\Reports\\Screenshots\\" + screenshotName));
			} catch (IOException e) {
				e.printStackTrace();
			}
			String screenShotPath = "..\\Reports\\Screenshots\\" + screenshotName;
			String image = test.addScreenCapture(screenShotPath);
			if (Status.equalsIgnoreCase("Pass")) {
				test.log(LogStatus.PASS, Step, image);
			} else {
				test.log(LogStatus.FAIL, Step, image);
				test.log(LogStatus.INFO, Decripion, "");
			}
		}

		if (ScreenShot.equalsIgnoreCase("no")) {
			if (Status.equalsIgnoreCase("Pass")) {
				test.log(LogStatus.PASS, Step + '\n' + Decripion, "Pass");
			} else {
				test.log(LogStatus.FAIL, Step, "Fail");
				test.log(LogStatus.INFO, Decripion, "");
			}
		}
		logger.info("updated status for the report.");
		extent.flush();
	}
	
}