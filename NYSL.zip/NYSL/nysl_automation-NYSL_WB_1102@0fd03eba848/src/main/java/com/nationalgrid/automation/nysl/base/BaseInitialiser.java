package com.nationalgrid.automation.nysl.base;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.nationalgrid.automation.nysl.utilities.ConfigHelper;
import com.nationalgrid.automation.nysl.utilities.ExcelHelper;

import cucumber.api.Scenario;

public class BaseInitialiser {

	public CustomReporter customReport = new CustomReporter();
	public static WebDriver driver;
//	public static WiniumDriver winDriver;
	public static Scenario scenario;
	public ExcelHelper testDataHelper = ExcelHelper.getInstance();
	public ConfigHelper configHelper = ConfigHelper.getInstance();

	
	public BaseInitialiser() {
		PageFactory.initElements(driver, this);
	}
}
