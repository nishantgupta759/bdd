package com.nationalgrid.automation.nysl.utilities;

public class PropHolder {

	private static String environment;
	private static String browserName;
	
	/* static{
		if(environment == null) {
			environment = System.getProperty("env");
			logger.info("PropHolder : Environment - " + environment);
			if(environment == null) {
				environment = ""; 
				logger.info("PropHolder : Environment  - " + environment);
			}
		}
	} */
	
	public static String getEnvironment() {
		return environment;
	}
	
	public static void setEnvironment(String env) {
		environment = env;
	}
	
	public static String getBrowserName() {
		return browserName;
	}
	
	public static void setBrowserName(String browser) {
		browserName = browser;
	}
}
