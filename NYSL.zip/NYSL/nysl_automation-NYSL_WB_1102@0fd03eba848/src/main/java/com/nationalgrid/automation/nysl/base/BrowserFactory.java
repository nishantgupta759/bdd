package com.nationalgrid.automation.nysl.base;



import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.winium.DesktopOptions;
import org.openqa.selenium.winium.WiniumDriver;
import org.openqa.selenium.winium.WiniumDriverService;

import com.nationalgrid.automation.nysl.utilities.AppUtility;
import com.nationalgrid.automation.nysl.utilities.ConfigHelper;

import io.github.bonigarcia.wdm.WebDriverManager;

public class BrowserFactory {
	
	public static WebDriver driver;
	public static WiniumDriver winDriver;
	public static WiniumDriverService service;
	static String desktopApplicationPath;
	static String SauceUserName = ConfigHelper.getInstance().getConfigProperty("sauceUsername");
	static String SauceAccessKey = ConfigHelper.getInstance().getConfigProperty("sauceAccessKey");
	private static Logger logger = Logger.getLogger(BrowserFactory.class);

	@SuppressWarnings("deprecation")
	public static void openBrowser(String browserType) throws MalformedURLException {
		
		switch(browserType.toLowerCase()) {
			
		/*
		 * case "chrome": //WebDriverManager.chromedriver().setup();
		 * //System.setProperty("webdriver.chrome.driver",
		 * "C:\\SeleniumDrivers\\chromedriver.exe");
		 * //System.setProperty("webdriver.chrome.driver",
		 * "C:\\Users\\erramp\\Documents\\eclipseworkspacedemoimpimp\\demo_cxp_automation_demo\\CXP_POC\\src\\main\\resources\\Drivers\\chromedriver.exe"
		 * ); //System.setProperty("webdriver.chrome.driver",
		 * "C:\\chromedriver\\chromedriver.exe");
		 * System.setProperty("webdriver.chrome.driver",
		 * "src/main/resources/Drivers/chromedriver.exe"); File directory = new
		 * File(System.getProperty("user.dir")+"\\Downloads");
		 * 
		 * File[] files = directory.listFiles(); if(files!=null) { for (File file :
		 * files) { file.delete(); if(!file.delete()){
		 * logger.info("Failed to delete "+file); } } } String downloadFilepath =
		 * System.getProperty("user.dir")+"\\Downloads";
		 * 
		 * HashMap<String, Object> chromePrefs = new HashMap<String, Object>();
		 * chromePrefs.put("profile.default_content_settings.popups", 0);
		 * chromePrefs.put("download.default_directory", downloadFilepath);
		 * 
		 * ChromeOptions options1 = new ChromeOptions();
		 * options1.setExperimentalOption("prefs", chromePrefs);
		 * 
		 * DesiredCapabilities cap = DesiredCapabilities.chrome();
		 * cap.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
		 * cap.setCapability(ChromeOptions.CAPABILITY, options1);
		 * 
		 * driver = new ChromeDriver(cap); break;
		 */
		case "chrome":
            System.setProperty("webdriver.chrome.driver", "src/main/resources/Drivers/chromedriver.exe");
            String downloadFilepath =System.getProperty("user.dir")+"\\src\\main\\resources\\Download";
            System.out.println(downloadFilepath);
            HashMap<String, Object> chromePrefs = new HashMap<String, Object>();
            chromePrefs.put("profile.default_content_settings.popups", 0);
            chromePrefs.put("download.default_directory", downloadFilepath);

            ChromeOptions options1 = new ChromeOptions();
            options1.setExperimentalOption("prefs", chromePrefs);
          
            DesiredCapabilities cap = DesiredCapabilities.chrome();
            cap.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
            cap.setCapability(ChromeOptions.CAPABILITY, options1);
              
            driver = new ChromeDriver(cap);
			break;
			
			case "firefox":
				WebDriverManager.firefoxdriver().setup();
				driver = new FirefoxDriver();
				break;
				
			case "ie":
				WebDriverManager.iedriver().setup();
				driver = new InternetExplorerDriver();
				break;
				
			case "saucechrome":

				ChromeOptions options = new ChromeOptions();
				options.setCapability("platform", "Windows 10");
				options.setCapability("version", "latest");
				options.setCapability("maxDuration", 10800);
				options.setCapability("username", SauceUserName);
				options.setCapability("accessKey", SauceAccessKey);
				options.setCapability("name", "CA Modman Smoke");
				options.setCapability("tunnelIdentifier", "myTunnel01");
				options.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
				options.setCapability(ChromeOptions.CAPABILITY, options);
				driver = new RemoteWebDriver(new URL("https://ondemand.saucelabs.com:443/wd/hub"),options);
				//driver = new RemoteWebDriver(new URL("https:"+SauceUserName+":9c3e2abc-e9fb-4c27-9166-f5769a635c93@ondemand.saucelabs.com:443/wd/hub/"),options);
				break;
			
			default:
				logger.info("Please give a valid browser name");
				break;
		}
		
	}
	
	
	
	/**
	 *Launches Browser
	 *maximise the browser
	 *wait for 5 seconds implicitly
	 * @return WebDriver
	 * @throws InterruptedException 
	 */
	public static WebDriver createWebDriver(String browserName)  {
		try {
		
					
			BrowserFactory.destroyDriver();
			AppUtility.waitForSpecificTime(1);
		
		
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		try {
		logger.info("Creating driver instance");
		//LogUtils.INFO("Creating driver instance");
		openBrowser(/* configUtils.getBrowserType() */ browserName);
		logger.info("driver instance has been successfully created");
		//LogUtils.INFO("driver instance has been successfully created");
		
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(12, TimeUnit.SECONDS);
		
		return driver;
	}
	
		
	/**
	 * driver.quit();
		driver=null;
	 */
	public static void destroyDriver() {
		if(driver!=null) {
			driver.quit();
			driver=null;
		}
		
		if(winDriver!=null) {
			try {
				winDriver.quit();
				service.stop();
				Runtime.getRuntime().exec("taskkill /F /IM Winium.Desktop.Driver.exe /t");
				winDriver=null;
			} catch (Exception e) {
				logger.info("Exception recorded in quiting winium driver");
				//LogUtils.INFO("Exception recorded in quiting winium driver");
			}
		}
		System.gc();
	}
	
	public static String openCamsApplication(String ApplicationName) {
		switch(ApplicationName.toLowerCase()) {
		case "calc":
			desktopApplicationPath=ConfigHelper.getInstance().getConfigProperty("AppPath");
			break;
		default:
			logger.info("Application not found. Please check application name or path.");
			//LogUtils.INFO("Application not found. Please check application name or path.");
			return null;
		}
		return desktopApplicationPath;
	}
	
	public static WiniumDriver createDesktopDriver(String applicationName) throws Exception {
			destroyDriver();
//			Runtime.getRuntime().exec(ConfigUtils.getConfigProperty("WiniumDriverPath")+" --port 8080");
			DesktopOptions options = new DesktopOptions();
			options.setApplicationPath(openCamsApplication(applicationName));
			File driverPath = new File(ConfigHelper.getInstance().getConfigProperty("WiniumDriverPath")); //+" --port 4545"
			service = new WiniumDriverService.Builder()
												.usingDriverExecutable(driverPath)
												.usingPort(9999)
												.withVerbose(true)
												.withSilent(false)
												.buildDesktopService();
			service.start();
			winDriver = new WiniumDriver(service, options);
//			driver = new WiniumDriver(new URL(ConfigUtils.getConfigProperty("WiniumPortURL")), options);
			return winDriver;
	}
}
