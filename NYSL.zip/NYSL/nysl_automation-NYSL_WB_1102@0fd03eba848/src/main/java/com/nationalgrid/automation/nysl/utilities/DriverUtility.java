package com.nationalgrid.automation.nysl.utilities;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Set;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.nationalgrid.automation.nysl.base.BrowserFactory;
import com.nationalgrid.automation.nysl.base.CustomReporter;
import static com.nationalgrid.automation.nysl.base.BrowserFactory.driver;

import io.qameta.allure.Allure;


public class DriverUtility {

	private static Logger logger = Logger.getLogger(DriverUtility.class);

    public static void clickElementByText(By element, String text) {
        List<WebElement> list = driver.findElements(element);
        for (WebElement item : list) {
            if (item.isDisplayed() && (item.getText() == text)) {
                item.click();
                return;
            }
        }
    }
    
    public static void verifyElementTextByRemovingSpclChars(WebElement element, String textToCompare, String stepName, String passStepStatus, String failStepStatus) throws Exception{
		waitForElementPresent(element);
		if(element.isDisplayed()){
			logger.info("Element Text : " + element.getText().trim().replaceAll("\\W", " "));
			logger.info("Text to compare: " + textToCompare.trim().replaceAll("\\W", " "));
			logger.info(element.getText().trim().replaceAll("\\W", " ").equals(textToCompare.trim().replaceAll("\\W", " ")));

			if(element.getText().trim().replaceAll("\\W", " ").equals(textToCompare.trim().replaceAll("\\W", " "))) {
				CustomReporter.flagResult("Pass", stepName, passStepStatus, "yes");	
			}else {
				CustomReporter.flagResult("Fail", stepName, failStepStatus + " has invalid text", "yes");	
			}
		}else{
			CustomReporter.flagResult("Fail", stepName, failStepStatus + " is not displayed", "yes");	
		}
	}
    
    public static void verifyElementText(WebElement element, String textToCompare, String stepName, String passStepStatus, String failStepStatus) throws Exception{
		waitForElementPresent(element);
		if(element.isDisplayed()){
			logger.info("Element Text : " + element.getText());
			if(element.getText().trim().equalsIgnoreCase(textToCompare.trim())) {
				CustomReporter.flagResult("Pass", stepName, passStepStatus, "yes");	
			}else {
				CustomReporter.flagResult("Fail", stepName, failStepStatus + " has invalid text", "yes");	
			}
		}else{
			CustomReporter.flagResult("Fail", stepName, failStepStatus + " is not displayed", "yes");	
		}
	}
			
    public static void verifyElementIsDisplayed(WebElement element, String stepName, String passStepStatus, String failStepStatus) throws Exception{
    	waitForElementPresent(element);
    	if(element.isDisplayed()){
    		CustomReporter.flagResult("Pass", stepName, passStepStatus, "yes");	
    	}else{
    		CustomReporter.flagResult("Fail", stepName, failStepStatus, "yes");	
    	}
    }		
    
    public static void verifyAbsenceOfElement(WebElement element, String stepName, String passStepStatus, String failStepStatus) throws Exception{
		waitForElementPresent(element);
		if(element.isDisplayed()){
			CustomReporter.flagResult("Fail", stepName, passStepStatus, "yes");	
		}else{
			CustomReporter.flagResult("Pass", stepName, failStepStatus, "yes");	
		}
	}		
	
    public static void clickElement(WebElement element, String elemName) throws Exception{
		waitForElementPresent(element);
		if(element.isDisplayed()){
			element.click();
			CustomReporter.flagResult("Pass", "Clicked on " + elemName, "Clicked", "yes");	
		}else{
			CustomReporter.flagResult("Fail", "Clicked on " + elemName, "Not Clicked", "yes");	
		}
	}
    
    private static WebDriverWait webdriverWait() {
		return new WebDriverWait(driver, 10);
	}
	
	public static void waitForElementPresent(WebElement elementToWaitFor) {
		try {
			webdriverWait().until(ExpectedConditions.visibilityOf(elementToWaitFor));
		}catch(Exception ex) {
			assertThat(ex)
            .withFailMessage("Element " + elementToWaitFor + " is not found")
            .isInstanceOf(NoSuchElementException.class);
		}
	}
	
	public static void waitForElementPresent(List<WebElement> elementToWaitFor) {
		try {
			for(WebElement elem : elementToWaitFor) {
				webdriverWait().until(ExpectedConditions.visibilityOf(elem));				
			}
		}catch(Exception ex) {
			assertThat(ex)
            .withFailMessage("Element " + elementToWaitFor + " is not found")
            .isInstanceOf(NoSuchElementException.class);
		}
	}
	
	public static void waitForElementToBeClickable(WebElement elementToWaitFor) {
		try {
			webdriverWait().until(ExpectedConditions.elementToBeClickable(elementToWaitFor));
		}catch(Exception ex) {
			assertThat(ex)
				.withFailMessage("Element " + elementToWaitFor + " is not clickable")
				.isInstanceOf(ElementClickInterceptedException.class);
		}
	}
	
	public static String getSnapshotFolderPath() {
		String path = ConfigHelper.getInstance().getConfigProperty("ScreenShotPath");
		return path;
	}

	public static String takeScreenShot() throws IOException {
		logger.info("Taking snapshot");
		File srcFile;
		if (driver != null) {
			srcFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		} else {
			srcFile = ((TakesScreenshot) BrowserFactory.winDriver).getScreenshotAs(OutputType.FILE);
		}
		DateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
		Calendar cal = Calendar.getInstance();
		String snapshotFileName = "screenshot" + dateFormat.format(cal.getTime()) + ".png";
		String pathToSnapshot = getSnapshotFolderPath() + "/" + snapshotFileName;
		FileUtils.copyFile(srcFile, new File(pathToSnapshot));
		return snapshotFileName;
	}

	public static void attachSnapshotToReport() {
		Path content = null;
		String snapshotFileName = null;
		try {
			snapshotFileName = takeScreenShot();
		} catch (IOException e2) {
			e2.printStackTrace();
		}
		content = Paths.get(getSnapshotFolderPath() + "/" + snapshotFileName);
		try (InputStream is = Files.newInputStream(content)) {
			Allure.addAttachment(snapshotFileName, is);
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

   // shifted from base steps - review , update as required	- start
	public static boolean isElementPresent(WebElement element){
		try {
			element.getAttribute("");
			return true;
		}catch(Exception e){
			return false;
		}
	}
	
	public boolean isElementPresent(String xpath){
		try {
			driver.findElement(By.xpath(xpath));
			return true;
		}catch(Exception e){
			return false;
		}
	}

	public static void selectFromDropdownUsingVisibleText(WebElement elementOfDropdown, String visibleText) {
		Select select = new Select(elementOfDropdown);
		select.selectByVisibleText(visibleText);
	}

	public void setValue(WebElement element, String value) throws InterruptedException{
		if(!value.trim().equalsIgnoreCase("<ignore>") && !value.trim().equals("")){
			int lenght= element.getAttribute("value").length();
			if(lenght>0){	
				element.sendKeys(Keys.END);
				for(int i=1;i<=lenght;i++){
					element.sendKeys(Keys.BACK_SPACE);
				}
			}
			element.sendKeys(value);
		}
	}
	
	public void rbSendKeys(Robot robot, String keys) {
	    for (char c : keys.toCharArray()) {
	        int keyCode = KeyEvent.getExtendedKeyCodeForChar(c);
	        if (KeyEvent.CHAR_UNDEFINED == keyCode) {
	            throw new RuntimeException("Key code not found for character '" + c + "'");
	        }
	        robot.keyPress(keyCode);
	        robot.delay(100);
	        robot.keyRelease(keyCode);
	        robot.delay(100);
	    }
	}

	public void selectElementUsingValue(WebElement selectElement, String value) {
		Select select = new Select(selectElement);
		select.deselectAll();
		select.selectByValue(value);
	}
	
	//Added Newly Sept20****************
	
	public static void isElementEnabled(WebElement element) throws Exception{
		try {
			element.isEnabled();
			CustomReporter.flagResult("Pass", element+ "is enabled", "Verified", "yes");
			//return true;
		}catch(Exception e){
			//return false;
			CustomReporter.flagResult("Pass", element+ "is enabled", "Verified", "yes");
		}
	}
	
	public static void isElementReadOnly(WebElement element) throws Exception{
		try {
			element.getAttribute("readonly");
			CustomReporter.flagResult("Pass", element+ "is Read Only", "Verified", "yes");
			//return true;
		}catch(Exception e){
			//return false;
			CustomReporter.flagResult("Pass", element+ "is Read Only", "Verified", "yes");
		}
	}
	
	public static WebElement expandRootElement(WebElement element) {
		WebElement ele = (WebElement) ((JavascriptExecutor)driver)
						.executeScript("return arguments[0].shadowRoot", element);
		return ele;
	}
	
	public static String getCurrentUrl() {
		String url  = driver.getCurrentUrl();
		return url;
	}
	
	public static void sendText(WebElement elem, String input, String elemName) throws Exception {
		DriverUtility.waitForElementPresent(elem);
		if(elem.isDisplayed()){
			elem.clear();
			elem.sendKeys(input);
			CustomReporter.flagResult("Pass", "Enter "+elemName, "Entered", "yes");
		}else{
			CustomReporter.flagResult("Fail", "Enter "+elemName, "Not Entered", "yes");	
		}
		
	}
	
	public static void isURLContains(String txtToVerify) throws Exception {
		if(getCurrentUrl().contains(txtToVerify)){
			CustomReporter.flagResult("Pass", "User navigated to '"+txtToVerify+"' page", "Verified", "yes");
		}else{
			CustomReporter.flagResult("Pass", "User navigated to '"+txtToVerify+"' page", "Not Verified", "yes");
		}
	}
	
		
	public static boolean performUploadFile(WebElement obj,String step,String filePath) throws Exception {
		boolean flag = false;
		try{
			DriverUtility.waitForElementPresent(obj);
			if(obj.isDisplayed()) {
	            obj.sendKeys(filePath);
				CustomReporter.flagResult("Pass", step, "Successfully Entered Path :"+filePath, "yes");	
				flag = true;
			}else{			
				CustomReporter.flagResult("Fail",step,"Object not present","yes");
			}
		}catch(Exception e) {
			CustomReporter.flagResult("Fail",step,e.getMessage(),"yes");
		}
		return flag;
	}
	
	public static String getAttributeFromObject(WebElement obj, String attribute) throws Exception {
		String attrVal = null; 
		try{
			attrVal = obj.getAttribute(attribute);	
		 } catch(Exception e){
			 CustomReporter.flagResult("Fail","Get the value from Element", "Failed to get the value due to exception:"+e.toString(),"yes");
		 }
		return attrVal;
	 }
	
	public static String getCssAttributeFromObject(WebElement obj, String attribute) throws Exception {
		String attrVal = null; 
		try {
			attrVal = obj.getCssValue(attribute);	
		 }catch(Exception e){
			 CustomReporter.flagResult("Fail","Get the CSS value from Element", "Failed to get the CSS value  due to exception:"+e.toString(),"yes");
		 }
		return attrVal;
	  }
	
	public static void mouseOverUsingActions(WebElement element) {
		Actions hover = new Actions(driver);
		hover.moveToElement(element).perform();
	}
	
	public static void mouseClickUsingActions(WebElement element) {
		Actions hover = new Actions(driver);
		hover.click(element).perform();
	}
	public static void mouseEnterUsingActions(WebElement element) {
		Actions act = new Actions(driver);
		act.sendKeys(Keys.ENTER);
	}
	
	public static void doubleClickUsingMouse(WebElement element) {
		Actions action = new Actions(driver) ;
		action.moveToElement(element).build().perform();
		action.doubleClick(element).build().perform();
	}
	
	public static void clickSVGElementUsingMouse(WebElement svgElement) throws Exception {
		if(svgElement.isDisplayed()){
			Actions actionBuilderObj = new Actions(driver);
			actionBuilderObj .click(svgElement).build().perform();
			CustomReporter.flagResult("Pass", "Click on " + svgElement, "Clicked", "yes");	
		}else{
			CustomReporter.flagResult("Fail", "Click on " + svgElement, "Not Clicked", "yes");	
		}
	}
	
	public static void switchWindow() {
		String currWindow=driver.getWindowHandle();
		Set<String> windows=driver.getWindowHandles();
		Iterator<String> iter = windows.iterator();
		while(iter.hasNext()){
			String childwindow=iter.next();
			if(!childwindow.equals(currWindow)){
				driver.switchTo().window(childwindow);
				break;
			}
		}
	}
	
	public static void verifyInputTextValue(WebElement elem, String input, String elemName,String postiveNegativeCase) throws Exception {
		DriverUtility.waitForElementPresent(elem);
		switch(postiveNegativeCase){
			case "Postive" :
				if(elem.isDisplayed()){
					 if (elem.getAttribute("value").equalsIgnoreCase(input)){
						 CustomReporter.flagResult("Pass", "input value "+input+" present", "present", "yes");
					 }else{
						 CustomReporter.flagResult("Fail", "input value "+input+" not present", "Not present", "yes");	
				    }
				}else{
					 CustomReporter.flagResult("Fail", "Element not found "+elemName, "Not found", "yes");	
				}
			break;
			case "Negative":
				if(elem.isDisplayed()){
					 if (elem.getAttribute("value").equalsIgnoreCase(input)){
						 CustomReporter.flagResult("Fail", "input value "+input+" present", "present", "yes");
					 }else{
						 CustomReporter.flagResult("Pass", "input value "+input+" not present", "Not present", "yes");	
				     }
				}else{	 
					 CustomReporter.flagResult("Fail", "Element not found "+elemName, "Not found", "yes");	
				}
			break;
		}
	}
	
	public static void getOptionsfromDropdown(WebElement element, String[] expArray) {
		WebElement dropdown = driver.findElement((By) element);  
		Select select = new Select(dropdown);  
		List<WebElement> options = select.getOptions();  
		for(WebElement we:options) {  
			for (int i=0; i<expArray.length; i++){
				if (we.getText().equals(expArray[i])){
				} 
			}
		}  
	}
	
 }