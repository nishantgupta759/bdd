package com.nationalgrid.automation.nysl.utilities;

import static com.nationalgrid.automation.nysl.utilities.AppConstants.EXCEL;
import static com.nationalgrid.automation.nysl.utilities.AppConstants.TESTDATA_FILENAME;
import static com.nationalgrid.automation.nysl.utilities.AppConstants.TESTDATA_PATH;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.util.NumberToTextConverter;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelHelper {

	private XSSFWorkbook testDataWorkBook = null;
	private static ExcelHelper helperObj;
	private Map<String, String> testDataMap = null;
	private static Logger logger = Logger.getLogger(ExcelHelper.class);

	
	private ExcelHelper() {}
	
	public static ExcelHelper getInstance() {
		if(helperObj == null) {
			synchronized (ExcelHelper.class) {
				if(helperObj == null) {
					logger.info("ExcelHelper : Initiating an object");
					helperObj = new ExcelHelper();
					helperObj.loadTestDataWorkBook();
				}
			}
		}
		return helperObj;
	}

	private void loadTestDataWorkBook() {
		try {
			if(testDataWorkBook == null) {
				String testDataFileName = getTestDataFileName();
				InputStream resourceStream = getClass().getResourceAsStream(getTestDataFileName());
				testDataWorkBook = new XSSFWorkbook(resourceStream);
				logger.info("ExcelHelper : Loaded test data file : " + testDataFileName);
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	private String getTestDataFileName() {
		if(PropHolder.getEnvironment() == null) {
			return TESTDATA_PATH + TESTDATA_FILENAME + EXCEL;
		}
		return TESTDATA_PATH + TESTDATA_FILENAME + "_" + PropHolder.getEnvironment() + EXCEL;
	}
	
	public Map<String, String> getDataMap(){
		return  testDataMap;
	}
	
	public Map<String, String> getDataForScenario(String scenarioName) {
		try {
		  if(testDataWorkBook == null) {
			  loadTestDataWorkBook();
		  }else {
			  logger.info("ExcelHelper : Workbook already in the memory.");
		  }
			if (scenarioName != null) {
				XSSFSheet sheet = testDataWorkBook.getSheet(scenarioName.split("-")[0]);
				int reqdCol = getColumnNumForScenario(scenarioName.split("-")[1], sheet);
				if(reqdCol > 0) {
					testDataMap = new HashMap<String, String>();
					testDataMap.put("Scenario Name", scenarioName);
					int numRows = sheet.getPhysicalNumberOfRows();
					logger.info("ExcelHelper : Number of rows : " + numRows);
					for(int rowNum = 1; rowNum < numRows; rowNum++) {
						String attrName = getCellValue(sheet.getRow(rowNum).getCell(0));
						String attrValue = getCellValue(sheet.getRow(rowNum).getCell(reqdCol));
						testDataMap.put(attrName, attrValue);
					}
				}else {
					logger.error("No data found for scenario : " + scenarioName);
				}
			}
		} catch (Exception e) {
			logger.error("Exception caught while reading data for scenario : " + scenarioName);
			e.printStackTrace();
		}
		logger.info("ExcelHelper testDataMap : " + testDataMap);
		return testDataMap;
	}
	
	private int getColumnNumForScenario(String scenarioName, XSSFSheet sheet) {
		Row scnNamesRow = sheet.getRow(0);
		int numCols = scnNamesRow.getPhysicalNumberOfCells();
		for(int colNum = 1; colNum <= numCols; colNum++) {
			Cell cell = scnNamesRow.getCell(colNum);
			String cellValue = getCellValue(cell);
			if(cellValue != null && !cellValue.equals("") && cellValue.equalsIgnoreCase(scenarioName)) {
				return colNum;
			}
		}
		// Scenario data not supplied
		return -1;
	}
	
	@SuppressWarnings("deprecation")
	private String getCellValue(Cell cell) {
		try {
			switch (cell.getCellType()) {
			case Cell.CELL_TYPE_STRING:
				return cell.getStringCellValue();

			case Cell.CELL_TYPE_BOOLEAN:
				return String.valueOf(cell.getBooleanCellValue());

			case Cell.CELL_TYPE_NUMERIC:
				return NumberToTextConverter.toText(cell.getNumericCellValue());
			}
		} catch (Exception e) {
			return "";
		}
		return "";
	}
	
}
