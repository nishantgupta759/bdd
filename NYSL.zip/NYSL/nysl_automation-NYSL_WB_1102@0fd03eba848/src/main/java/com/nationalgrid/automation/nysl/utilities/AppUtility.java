package com.nationalgrid.automation.nysl.utilities;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.InputStream;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.time.DateUtils;
import org.apache.log4j.Logger;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.sikuli.script.Finder;
import org.sikuli.script.Match;
import org.sikuli.script.Pattern;
import org.sikuli.script.Screen;

import com.nationalgrid.automation.nysl.base.CustomReporter;

import net.lingala.zip4j.core.ZipFile;
import net.lingala.zip4j.exception.ZipException;

public class AppUtility {

	private static Logger logger = Logger.getLogger(AppUtility.class);
	static Map<String, Date> inputDateMap = new HashMap<String, Date>();
	static SimpleDateFormat dateFrmtr = new SimpleDateFormat("MMM dd, yyyy");
	static int counterScreenshot = 0;

	public static void waitForSpecificTime(long numOfSeconds) {
		try {
			Thread.sleep(numOfSeconds * 1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
			logger.error("Exception caught while waiting for " + numOfSeconds + "seconds");
		}
	}

	public static List<String> getExtraPaginationButton() {
		List<String> extraBtns = new ArrayList<String>();
		extraBtns.add("first");
		extraBtns.add("prev");
		extraBtns.add("next");
		extraBtns.add("last");
		return extraBtns;
	}

	public static void constructCriteriaDateMap() throws ParseException {
		Date currDate = dateFrmtr.parse(dateFrmtr.format(new Date()));
		inputDateMap.put("PAYMENT DUE NOW", dateFrmtr.parse("Jan 01, 1990"));
		inputDateMap.put("PAYMENT SCHEDULED", DateUtils.addYears(currDate, 10));
		inputDateMap.put("NO PAYMENT DUE", DateUtils.addYears(currDate, 11));
		inputDateMap.put("ACCOUNT FINALED WITH BALANCE", DateUtils.addYears(currDate, 12));
		inputDateMap.put("ACCOUNT FINALED", DateUtils.addYears(currDate, 13));
	}

	public static Date getTransformedDate(String input) throws ParseException {
		Date transfrmdDate;
		if (input.startsWith("PAY BY")) {
			String dateStr = input.replace("PAY BY ", "");
			transfrmdDate = dateFrmtr.parse(dateStr);
		} else {
			transfrmdDate = inputDateMap.get(input);
		}
		return transfrmdDate;
	}

	// Added Sept20*************
	public static File[] isFileDownloaded(String nameFile) throws Exception {
		//File folderDownload = new File("src/main/resources/Download");
		File folderDownload = new File(System.getProperty("user.dir")+"\\Downloads");
		System.out.println("absolute path for the Folder Downloaded is  : " + folderDownload.getAbsolutePath());
		File[] listFiles = folderDownload.listFiles();
		boolean found = false;
		File file = null;

		for (File listOfFile : listFiles) {
			if (listOfFile.isFile()) {
				String fileName = listOfFile.getName();
				System.out.println("File " + listOfFile.getName());
				// if (fileName.matches(nameFile)) {
				if (fileName.contains(nameFile)) {
					file = new File(nameFile);
					found = true;
				}
			}
		}
		if (found) {
			CustomReporter.flagResult("Pass", "The '" + nameFile + "' file is Downloaded", "Verified", "yes");
		} else {
			CustomReporter.flagResult("Fail", "The '" + nameFile + "' File is Downloaded", "Not Verifed", "yes");
		}

		return listFiles;
		// file.deleteOnExit();
	}

	public static String getRandomNumUsingTime() {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(calendar.getTime());
		int month = Calendar.MONTH;
		int day = Calendar.DAY_OF_MONTH;
		int hours = calendar.get(Calendar.HOUR_OF_DAY);
		int minutes = calendar.get(Calendar.MINUTE);
		int seconds = calendar.get(Calendar.SECOND);
		counterScreenshot = counterScreenshot + 1;
		String Rand = counterScreenshot + Integer.toString(month) + Integer.toString(day) + Integer.toString(hours)
				+ Integer.toString(minutes) + Integer.toString(seconds);
		return Rand;
	}

	public static String dynamicXpath(String element, String argument) {
		// String str = element.toString();
		String[] a = element.split("xxxx");
		return a[0] + argument + a[1];
	}

	public static void isPDFOpenedInURLContains(String textToCompare, boolean lineBreaker) throws Exception {

		URL url = new URL(DriverUtility.getCurrentUrl());
		InputStream is = url.openStream();
		BufferedInputStream fileToParse = new BufferedInputStream(is);
		PDDocument doc = null;
		String ContentText = null;

		try {
			doc = PDDocument.load(fileToParse);
			ContentText = new PDFTextStripper().getText(doc);

			if (!lineBreaker)
				ContentText = ContentText.replaceAll("\\s", "");
			System.out.println(ContentText);

		} finally {
			if (doc != null) {
				doc.close();
			}
			fileToParse.close();
			is.close();
		}
		if (ContentText.contains(textToCompare)) {
			CustomReporter.flagResult("Pass", "'" + textToCompare + "' is present", "Verified", "yes");
		} else {
			CustomReporter.flagResult("Fail", "'" + textToCompare + "' is present", "Not Verified", "yes");
		}

	}

	public static void isMultiplePagesPDFOpenedInURLContains(String textToCompare, boolean lineBreaker,
			int firstPageNumberofPDF, int lastPageNumberofPDF) throws Exception {

		URL url = new URL(DriverUtility.getCurrentUrl());
		InputStream is = url.openStream();
		BufferedInputStream fileToParse = new BufferedInputStream(is);
		PDDocument doc = null;
		String ContentText = null;
		PDFTextStripper pdfStripper = null;

		try {
			doc = PDDocument.load(fileToParse);
			pdfStripper = new PDFTextStripper();
			pdfStripper.setStartPage(firstPageNumberofPDF);
			pdfStripper.setEndPage(lastPageNumberofPDF);
			ContentText = pdfStripper.getText(doc);

			if (!lineBreaker)
				ContentText = ContentText.replaceAll("\\s", "");
			System.out.println(ContentText);

		} finally {
			if (doc != null) {
				doc.close();
			}
			fileToParse.close();
			is.close();
		}
		if (ContentText.contains(textToCompare)) {
			CustomReporter.flagResult("Pass", "'" + textToCompare + "' is present", "Verified", "yes");
		} else {
			CustomReporter.flagResult("Fail", "'" + textToCompare + "' is present", "Not Verified", "yes");
		}

	}

	public static void compareImageWithApplication(String fileName) throws Exception {
		Screen screen = new Screen();
		Pattern pa1 = new Pattern(fileName);
		Finder f1 = new Finder(screen.capture().getImage());
		f1.find(pa1);
		if (f1.hasNext()) {

			Match m = f1.next();
			double matchPercent = m.getScore() * 100;

			System.out.println("Match found with " + (m.getScore()) * 100 + "%");

			if (matchPercent == 100) {
				CustomReporter.flagResult("Pass", "Images matching to " + matchPercent + "%", "Verified", "yes");
			} else {
				CustomReporter.flagResult("Fail", "Images matching to " + matchPercent + "%", "Not Verified", "yes");
			}

			f1.destroy();

		} else {

			System.out.println("No Matching Image Found");
		}
	}

	public static void unzipFile(String srcFile, String destFile, String password) {
		try {
			ZipFile zipFile = new ZipFile(srcFile);
			if (zipFile.isEncrypted()) {
				zipFile.setPassword(password);
			}
			zipFile.extractAll(destFile);
		} catch (ZipException e) {
			e.printStackTrace();
		}
	}	
}
