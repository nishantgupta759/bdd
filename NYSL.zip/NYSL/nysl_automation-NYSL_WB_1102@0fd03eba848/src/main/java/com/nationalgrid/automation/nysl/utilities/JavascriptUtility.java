package com.nationalgrid.automation.nysl.utilities;

import java.util.NoSuchElementException;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebElement;

import com.nationalgrid.automation.nysl.base.BrowserFactory;
import com.nationalgrid.automation.nysl.base.CustomReporter;

public class JavascriptUtility {
	
	
	public static WebElement expandShadowRootElement(WebElement element) {
		JavascriptExecutor je = (JavascriptExecutor) BrowserFactory.driver;
		WebElement ele = (WebElement) (je.executeScript("return arguments[0].shadowRoot", element));
		return ele;
	}
	
	public static void clickUsingJS(WebElement elementToClick) throws Exception {
		JavascriptExecutor je = (JavascriptExecutor) BrowserFactory.driver;
		if(elementToClick.isDisplayed()) {
			je.executeScript("arguments[0].click();",elementToClick);
			CustomReporter.flagResult("Pass", "Click on " + elementToClick.getText(), "Clicked", "yes");	
		}else{
			CustomReporter.flagResult("Fail", "Click on " + elementToClick.getText(), "Not Clicked", "yes");	
		}
	}
	
	public static String getTitleUsingJS() {
		JavascriptExecutor je = (JavascriptExecutor) BrowserFactory.driver;
		String pageTitle =  je.executeScript("return document.title;").toString();
		return pageTitle;
	}
	
	public static void scrollToElementUsingJS(WebElement element) {
		JavascriptExecutor je = (JavascriptExecutor) BrowserFactory.driver;
		je.executeScript("arguments[0].scrollIntoView(true);", element);
	}

	public static void setValueUsingJS(WebElement element, String valueToBeSet) throws Exception {
		JavascriptExecutor je = (JavascriptExecutor) BrowserFactory.driver;
		if(element.isDisplayed()) {
			je.executeScript("arguments[0].value = '';", element);
			//element.sendKeys(valueToBeSet);
			CustomReporter.flagResult("Pass", "�"+valueToBeSet+"� is entered in " + element, "Clicked", "yes");	
		}else{
			CustomReporter.flagResult("Fail", "�"+valueToBeSet+"� is entered in " + element, "Not Clicked", "yes");	
		}
	}
	
	public static void clickHiddenElemUsingJS(WebElement element) throws Exception {
		JavascriptExecutor je = (JavascriptExecutor) BrowserFactory.driver;
		if(element.isDisplayed()) {
			je.executeScript("arguments[0].click();", element);
			CustomReporter.flagResult("Pass", "Click on " + element, "Clicked", "yes");
		}else{
			CustomReporter.flagResult("Fail", "Click on " + element, "Not Clicked", "yes");	
		}
	}
	
	public static void setDateUsingJS(WebElement element, String date) throws Exception {
		JavascriptExecutor je = (JavascriptExecutor) BrowserFactory.driver;
		if(element.isDisplayed()) {
			je.executeScript("arguments[0].setAttribute('value', '"+date+"')", element);
			CustomReporter.flagResult("Pass", "Date is entered in " + element, "Clicked", "yes");	
		}else{
			CustomReporter.flagResult("Fail", "Date is entered in " + element, "Not Clicked", "yes");	
		}
	}
	
	public static void highlighElemUsingJS(WebElement element) throws Exception {
		JavascriptExecutor je = (JavascriptExecutor) BrowserFactory.driver;
		if(element.isDisplayed()) {
		je.executeScript("arguments[0].style.border='3px dotted blue'", element);
			CustomReporter.flagResult("Pass", "Highlighted " + element, "Clicked", "yes");	
		}else{
			CustomReporter.flagResult("Fail", "Highlighted " + element, "Not Clicked", "yes");	
		}
	}
	
	public static void refreshPageUsingJS() {
		JavascriptExecutor je = (JavascriptExecutor) BrowserFactory.driver;
		je.executeScript("history.go(0)");
	}
	
	public static void isElemPresentUsingJS(WebElement element) throws Exception {
		JavascriptExecutor je = (JavascriptExecutor) BrowserFactory.driver;
        try {
            Object obj = je.executeScript("return typeof(arguments[0]) != 'undefined' && arguments[0] != null;",element);
            if (obj.toString().contains("true")) {
            	CustomReporter.flagResult("Pass", element +"is present", "Verified", "yes");
            } else {
            	CustomReporter.flagResult("Fail", element +"is present", "Not Verified", "yes");
            }
        } catch (NoSuchElementException e) {
            System.out.println("isElementPresentCheckUsingJavaScriptExecutor: FAIL");
        }
    }
	
	public static String getAllCSSValElement(WebElement element) {
		JavascriptExecutor je = (JavascriptExecutor) BrowserFactory.driver;
		String script = "var s = '';" +
                "var o = getComputedStyle(arguments[0]);" +
                "for(var i = 0; i < o.length; i++){" +
                "s+=o[i] + ':' + o.getPropertyValue(o[i])+';';}" + 
                "return s;";
		String allCss = je.executeScript(script, element).toString();
		return allCss;
	}

	public static void scrollStillPxJS(WebElement element, int stillToGoUp) {
		JavascriptExecutor je = (JavascriptExecutor) BrowserFactory.driver;
		Point locate = element.getLocation();
		int x = locate.getX();
		int y = locate.getY();
		je.executeScript("window.scrollTo(" + x + "," + (y - stillToGoUp) + ")");
	}
}