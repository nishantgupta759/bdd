package com.nationalgrid.automation.nysl.steps;

import org.openqa.selenium.support.PageFactory;

import com.nationalgrid.automation.nysl.actions.LandingPageActions;
import com.nationalgrid.automation.nysl.base.BaseInitialiser;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;

public class LandingPageSteps extends BaseInitialiser {
	
	LandingPageActions requestActions = PageFactory.initElements(driver, LandingPageActions.class);

	@Then("^Verify if user is in Streetlight Landing Page$")
	public void verify_if_User_is_in_Streetlight_Landing_Page() throws Throwable {
		requestActions.verifyLandingPage();
	}
	
	@And("^User clicks on Outage option$")
	public void user_clicks_on_Outage_option() throws Throwable {
		requestActions.clickOutageOptions();
	}
	
	@Then("^User clicks on FAQ link$")
	public void user_clicks_on_FAQ_link() throws Throwable {
		requestActions.clickOnFAQ();
	}
	
	
}
