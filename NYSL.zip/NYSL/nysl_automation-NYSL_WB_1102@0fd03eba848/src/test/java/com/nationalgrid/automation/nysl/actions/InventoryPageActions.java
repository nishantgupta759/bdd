package com.nationalgrid.automation.nysl.actions;

import com.nationalgrid.automation.nysl.locators.InventoryPageLocators;
import com.nationalgrid.automation.nysl.utilities.DriverUtility;

public class InventoryPageActions extends InventoryPageLocators {
		
	public void userEntersEmailId(String input) throws Exception {
		DriverUtility.sendText(emailField, input, "email Field");
	}

	public void userEntersPassword(String input) throws Exception {
		DriverUtility.sendText(passwordField, input, "password Field");
	}
	
	public void userClicksOnSignInButton() throws Exception {
		DriverUtility.clickElement(signInField, "signIn Field");
	}
	
	public void verifyAccountSelectionPageUrl() throws Exception {
		DriverUtility.isURLContains("/InventoryAccount");
	}
	
	public void verifyIfLoadingIsDisplayed() throws Exception {
		DriverUtility.verifyElementIsDisplayed(loadingText, "User verifies loadingText", "User verified loadingText", "User failed to verify loadingText");
	}
	
	public void clickOnCancelButton() throws Exception {
		DriverUtility.clickElement(cancelButton, "Cancel Button");
	}
	
	public void clickOnSelectAccountButtonForMaster() throws Exception {
		DriverUtility.clickElement(selectAccountForMaster, "selectAccount Button");
	}
	
	public void clickOnSelectAccountButtonForReferenceAccount() throws Exception {
		DriverUtility.clickElement(selectAccountForReference, "selectAccount Button");
	}
	
	public void verifyReferenceNumbersPageUrl() throws Exception {
		DriverUtility.isURLContains("/InventoryAccount/InventoryReferenceInfo");
	}
	
	public void verifyInventoryReportPageUrl() throws Exception {
		DriverUtility.isURLContains("/InventoryAccount/InventoryReport");
	}
	
	public void verifyReferenceNumbersPageHeading() throws Exception {
		DriverUtility.verifyElementIsDisplayed(referenceNumbersPageHeading, "User verifies referenceNumbersPageHeading", "User verified referenceNumbersPageHeading", "User failed to verify referenceNumbersPageHeading");
	}
	
	public void verifyInventoryReportPageHeading() throws Exception {
		DriverUtility.verifyElementIsDisplayed(inventoryReportPageHeading, "User verifies inventoryReportPageHeading", "User verified inventoryReportPageHeading", "User failed to verify inventoryReportPageHeading");
	}
	
	public void verifyIfMasterAccountsHaveSelectAccountButton() throws Exception {
		DriverUtility.verifyElementIsDisplayed(selectAccountForMaster, "User verifies selectAccount button", "User verified selectAccount button", "User failed to verify selectAccount button");
	}
	
	public void verifyIfAddAccountButtonIsDisplayed() throws Exception {
		DriverUtility.verifyElementIsDisplayed(addAccount, "User verifies addAccount button", "User verified addAccount button", "User failed to verify addAccount button");
	}
	
	public void verifyIfReferenceAccountsHaveSelectAccountButton() throws Exception {
		DriverUtility.verifyElementIsDisplayed(selectAccountForReference, "User verifies selectAccount button", "User verified selectAccount button", "User failed to verify selectAccount button");
	}
	
	public void verifyIfAccountNumbersColumnIsDisplayed() throws Exception {
		DriverUtility.verifyElementIsDisplayed(accountNumbers, "User verifies accountNumbers", "User verified accountNumbers", "User failed to verify accountNumbers");
	}
	
	public void verifyIfInEligibilityAccountIsDisplayed() throws Exception {
		DriverUtility.verifyElementIsDisplayed(notAStreetlightAccount, "User verifies notAStreetlightAccount", "User verified notAStreetlightAccount", "User failed to verify notAStreetlightAccount");
	}
	
	public void verifyIfElectricAccountIsDisplayed() throws Exception {
		DriverUtility.verifyElementIsDisplayed(electricAccount, "User verifies electricAccount", "User verified electricAccount", "User failed to verify electricAccount");
	}
	
	public void verifyIfGasAccountIsDisplayed() throws Exception {
		DriverUtility.verifyElementIsDisplayed(gasAccount, "User verifies gasAccount", "User verified gasAccount", "User failed to verify gasAccount");
	}
	
	public void verifyIfCustomerNameFieldIsDisplayed() throws Exception {
		DriverUtility.verifyElementIsDisplayed(customerNameKey, "User verifies customerNameKey", "User verified customerNameKey", "User failed to verify customerNameKey");
		DriverUtility.verifyElementIsDisplayed(customerNameValue, "User verifies customerNameValue", "User verified customerNameValue", "User failed to verify customerNameValue");
	}
	
	public void verifyIfMasterAccountFieldIsDisplayed() throws Exception {
		DriverUtility.verifyElementIsDisplayed(masterAccountKey, "User verifies masterAccountKey", "User verified masterAccountKey", "User failed to verify masterAccountKey");
		DriverUtility.verifyElementIsDisplayed(masterAccountValue, "User verifies masterAccountValue", "User verified masterAccountValue", "User failed to verify masterAccountValue");
	}
	
	public void verifyIfAddressFieldIsDisplayed() throws Exception {
		DriverUtility.verifyElementIsDisplayed(addressKey, "User verifies addressKey", "User verified addressKey", "User failed to verify addressKey");
		DriverUtility.verifyElementIsDisplayed(addressValue, "User verifies addressValue", "User verified addressValue", "User failed to verify addressValue");
	}
	
	public void verifyIfSearchOptionIsDisplayed() throws Exception {
		DriverUtility.verifyElementIsDisplayed(searchForReferenceNumber, "User verifies searchForReferenceNumber", "User verified searchForReferenceNumber", "User failed to verify searchForReferenceNumber");
	}
	
	public void verifyIfExportAllButtonDisplayed() throws Exception {
		DriverUtility.verifyElementIsDisplayed(exportAllButtonRefPage, "User verifies exportAllButtonRefPage", "User verified exportAllButtonRefPage", "User failed to verify exportAllButtonRefPage");
	}
	
	public void verifyIfCheckboxesAreDisplayedForEachRow() throws Exception {
		DriverUtility.verifyElementIsDisplayed(checkboxColRefPage, "User verifies checkboxColRefPage", "User verified checkboxColRefPage", "User failed to verify checkboxColRefPage");
	}
	
	public void verifyIfReferenceNumberIsDisplayedForEachRow() throws Exception {
		DriverUtility.verifyElementIsDisplayed(referenceNumberColRefPage, "User verifies referenceNumberColRefPage", "User verified referenceNumberColRefPage", "User failed to verify referenceNumberColRefPage");
	}
	
	public void verifyIfAddressIsDisplayedForEachRow() throws Exception {
		DriverUtility.verifyElementIsDisplayed(addressColRefPage, "User verifies addressColRefPage", "User verified addressColRefPage", "User failed to verify addressColRefPage");
	}
	
	public void verifyIfViewButtonIsDisplayedForEachRow() throws Exception {
		DriverUtility.verifyElementIsDisplayed(viewCTAButtonRefPage, "User verifies viewCTAButtonRefPage", "User verified viewCTAButtonRefPage", "User failed to verify viewCTAButtonRefPage");
	}
	
	public void clickOnViewButtonOnReferenceNumbersPage() throws Exception {
		DriverUtility.clickElement(viewCTAButtonRefPage, "viewCTAButtonRefPage");
	}
	
	public void clickOnAnyCheckboxOnReferenceNumbersPage() throws Exception {
		DriverUtility.clickElement(firstCheckbox, "firstCheckbox");
	}
	
	public void verifyHyperlinksOnInventoryReportPage() throws Exception {
		DriverUtility.verifyElementIsDisplayed(referenceNumBreadcrumb, "User verifies referenceNumBreadcrumb", "User verified referenceNumBreadcrumb", "User failed to verify referenceNumBreadcrumb");
		DriverUtility.verifyElementIsDisplayed(accountListBreadcrumb, "User verifies referenceNumBreadcrumb", "User verified referenceNumBreadcrumb", "User failed to verify referenceNumBreadcrumb");
		DriverUtility.verifyElementIsDisplayed(streetLightBreadcrumb, "User verifies referenceNumBreadcrumb", "User verified referenceNumBreadcrumb", "User failed to verify referenceNumBreadcrumb");
	}
	public void verifyHyperlinksOnReferenceNumbersPage() throws Exception {
		DriverUtility.verifyElementIsDisplayed(accountListBreadcrumb, "User verifies referenceNumBreadcrumb", "User verified referenceNumBreadcrumb", "User failed to verify referenceNumBreadcrumb");
		DriverUtility.verifyElementIsDisplayed(streetLightBreadcrumb, "User verifies referenceNumBreadcrumb", "User verified referenceNumBreadcrumb", "User failed to verify referenceNumBreadcrumb");
	}
	
	public void clickOnReferenceNumBreadcrumbOnInventoryPage() throws Exception {
		DriverUtility.clickElement(referenceNumBreadcrumb, "referenceNumBreadcrumb");
	}

	public void clickOnAccountListBreadcrumbOnInventoryPage() throws Exception {
		DriverUtility.clickElement(accountListBreadcrumb, "accountListBreadcrumb");
	}
	
	public void clickOnBackButtonOnInvetoryReportPage() throws Exception {
		DriverUtility.clickElement(backButton, "back button of Inventory Report page");
	}
	
	public void clickOnBackButtonOnReferenceNumbersPage() throws Exception {
		DriverUtility.clickElement(backButton, "back button of ReferenceNumbers page");
	}
	
	public void clickOnBackButtonOnAccountListPage() throws Exception {
		DriverUtility.clickElement(backButton, "back button of AccountList page");
	}
	
	public void clickOnCancelButtonOnAccountListPage() throws Exception {
		DriverUtility.clickElement(cancelButton, "Cancel button of AccountList page");
	}
	
	public void clickOnCheckboxHeadingOnReferenceNumbersPage() throws Exception {
		DriverUtility.clickElement(checkBoxHeading, "checkBoxHeading");
	}
	
	public void checkMultipleCheckboxesOnReferenceNumbersPage() throws Exception {
		DriverUtility.clickElement(checkBox1, "checkBox1");
		DriverUtility.clickElement(checkBox2, "checkBox2");
	}
	
	public void verifyModalPopUpOnReferenceNumbersPage() throws Exception {
		DriverUtility.verifyElementIsDisplayed(modalPopUp, "User verifies modalPopUp", "User verified modalPopUp", "User failed to verify modalPopUp");
		DriverUtility.verifyElementIsDisplayed(accountsSelectedPopup, "User verifies accountsSelectedPopup", "User verified accountsSelectedPopup", "User failed to verify accountsSelectedPopup");
		DriverUtility.verifyElementIsDisplayed(exportCSVPopup, "User verifies exportCSVPopup", "User verified exportCSVPopup", "User failed to verify exportCSVPopup");
	}
	
	public void verifyPaginationOnReferenceNumbersPage() throws Exception {
		DriverUtility.verifyElementIsDisplayed(pagination, "User verifies pagination", "User verified pagination", "User failed to verify pagination");
		DriverUtility.verifyElementIsDisplayed(paginationFirstButton, "User verifies paginationFirstButton", "User verified paginationFirstButton", "User failed to verify paginationFirstButton");
		DriverUtility.verifyElementIsDisplayed(paginationNextButton, "User verifies paginationNextButton", "User verified paginationNextButton", "User failed to verify paginationNextButton");
		DriverUtility.verifyElementIsDisplayed(paginationPrevButton, "User verifies paginationPrevButton", "User verified paginationPrevButton", "User failed to verify paginationPrevButton");
		DriverUtility.verifyElementIsDisplayed(paginationLastButton, "User verifies paginationLastButton", "User verified paginationLastButton", "User failed to verify paginationLastButton");
	}
	
	public void verifySwitchToMapViewIsDisplayed() throws Exception {
		DriverUtility.verifyElementIsDisplayed(switchToMapView, "User verifies switchToMapView", "User verified switchToMapView", "User failed to verify switchToMapView");
	}
	
	public void verifyDefaultViewIsTableView() throws Exception {
		DriverUtility.verifyElementIsDisplayed(tableView, "User verifies tableView", "User verified tableView", "User failed to verify tableView");
	}
	
	public void verifyIfCommunicationAddressIsDisplayed() throws Exception {
		DriverUtility.verifyElementIsDisplayed(addressValue, "User verifies addressValue", "User verified addressValue", "User failed to verify addressValue");
	}
	
	public void verifyIfCommunicationAddressIsDisplayedOnAccountListsPage() throws Exception {
		DriverUtility.verifyElementIsDisplayed(addressFieldOnAccountPage, "User verifies addressFieldOnAccountPage", "User verified addressFieldOnAccountPage", "User failed to verify addressFieldOnAccountPage");
	}
	
	public void verifyInventoryReportHeader() throws Exception {
		DriverUtility.verifyElementIsDisplayed(locationID, "User verifies locationID", "User verified locationID", "User failed to verify locationID");
		DriverUtility.verifyElementIsDisplayed(poleNo, "User verifies poleNo", "User verified poleNo", "User failed to verify poleNo");
		DriverUtility.verifyElementIsDisplayed(poleSuffix, "User verifies poleSuffix", "User verified poleSuffix", "User failed to verify poleSuffix");
		DriverUtility.verifyElementIsDisplayed(seq, "User verifies seq", "User verified seq", "User failed to verify seq");
		DriverUtility.verifyElementIsDisplayed(streetName, "User verifies streetName", "User verified streetName", "User failed to verify streetName");
		DriverUtility.verifyElementIsDisplayed(componentType, "User verifies componentType", "User verified componentType", "User failed to verify componentType");
		DriverUtility.verifyElementIsDisplayed(billCodeTitle, "User verifies billCodeTitle", "User verified billCodeTitle", "User failed to verify billCodeTitle");
		DriverUtility.verifyElementIsDisplayed(lightStatus, "User verifies lightStatus", "User verified lightStatus", "User failed to verify lightStatus");
		DriverUtility.verifyElementIsDisplayed(sourceType, "User verifies sourceType", "User verified sourceType", "User failed to verify sourceType");
	}
	
	
}