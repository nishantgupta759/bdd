package com.nationalgrid.automation.nysl.actions;

import com.nationalgrid.automation.nysl.locators.FAQLocators;
import com.nationalgrid.automation.nysl.utilities.AppUtility;
import com.nationalgrid.automation.nysl.utilities.DriverUtility;
import com.nationalgrid.automation.nysl.utilities.JavascriptUtility;

public class FAQActions extends FAQLocators {
	
	String home = System.getProperty("user.home");
	
	public void verifyFAQPageURL() throws Exception{
		DriverUtility.isURLContains("/Upstate-NY-Business/Streetlight-Portal/Streetlight-Frequently-Asked-Questions");
	}
	
	public void verifyIfOptInTextisDisplayed() throws Exception {
		DriverUtility.verifyElementIsDisplayed(optInHeading, "verify optInHeading", "verified optInHeading", "Unable to verify optInHeading");
	}
	
	public void verifyOptInLinkisDisplayed() throws Exception {
		DriverUtility.verifyElementIsDisplayed(optInLink, "verify optInLink", "verified optInLink", "Unable to verify optInLink");
	}
	
	public void clickOptInLink() throws Exception {
		JavascriptUtility.scrollToElementUsingJS(optInLink);
		JavascriptUtility.clickUsingJS(optInLink);
	}
	
	public void verifyIfOptInFormIsdownloaded() throws Exception {
		AppUtility.isFileDownloaded("opt-in-streetlight-replacement-form.xlsx");
	}
	
	public void verifyAssetSalesText() throws Exception {
		DriverUtility.verifyElementIsDisplayed(assetSales, "verify assetSales", "verified assetSales", "Unable to verify assetSales");
	}
	
	public void verifyHowToReportStreelightOutageQuestion() throws Exception {
		DriverUtility.verifyElementIsDisplayed(howToReportQ, "verify howToReportQ", "verified howToReportQ", "Unable to verify howToReportQ");
	}
	
	public void clickOnHowToReportStreelightOutageQuestion() throws Exception {
		DriverUtility.clickElement(howToReportQ, "howToReportQ");
	}
	
	public void clickOnStreelightRepairLink() throws Exception {
		DriverUtility.clickElement(streetlightRepairLink, "streetlightRepairLink");
	}
	
	public void verifyStreelightRepairLinkIsDisplayed() throws Exception {
		DriverUtility.verifyElementIsDisplayed(streetlightRepairLink, "verify streetlightRepairLink", 
				"verified streetlightRepairLink", "Unable to verify streetlightRepairLink");
	}

}