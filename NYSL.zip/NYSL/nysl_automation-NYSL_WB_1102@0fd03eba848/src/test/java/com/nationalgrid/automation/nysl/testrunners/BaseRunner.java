package com.nationalgrid.automation.nysl.testrunners;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.cucumber.listener.ExtentCucumberFormatter;
import com.nationalgrid.automation.nysl.base.CustomReporter;
import com.nationalgrid.automation.nysl.utilities.ConfigHelper;
import com.nationalgrid.automation.nysl.utilities.ExcelHelper;
import com.nationalgrid.automation.nysl.utilities.PropHolder;
import com.relevantcodes.extentreports.ExtentReports;

import cucumber.api.CucumberOptions;

@Test
@CucumberOptions(
		features="src/test/resources/feature"
		,glue="com.nationalgrid.automation.nysl.steps"
		,plugin= {"junit:target/cucumber-report.xml", "io.qameta.allure.cucumberjvm.AllureCucumberJvm", "com.cucumber.listener.ExtentCucumberFormatter:output/myreport.html"}
		//,tags= {"@CXP_POC"}
		)

public class BaseRunner extends CustomTestngCucumberRunner{
	
	private static Logger logger = Logger.getLogger(BaseRunner.class);
	
	@BeforeClass
	public static void initial() throws Exception {
		logger.info("Base Runner -> BeforeClass -> initial()");
		logger.info("BaseRunner : To configure Extent reports - START");
		logger.info("Cucumber options : " + System.getProperty("cucumber.options"));
		ExtentCucumberFormatter.initiateExtentCucumberFormatter();
		ExtentCucumberFormatter.loadConfig(new File("src/extent-config.xml"));
		
		CustomReporter.timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date()).replace(".", "");
		CustomReporter.resultLocation = System.getProperty("user.dir") + "\\Results";
		CustomReporter.extent = new ExtentReports(CustomReporter.resultLocation + "\\Reports\\Run" + CustomReporter.timeStamp + ".html", true);
		logger.info("BaseRunner : To configure Extent reports - END");
	}	
	
	//TODO: remove tid n verify.. also reanme tid in all required classes.
	@Parameters({"browserName", "environment", "tags"})
    @BeforeTest
    public void setEnvDetails(@Optional("Chrome") String browserName, @Optional("qa") String environment, String tags) {
        logger.info("BaseRunner : Browser for this test set is " + browserName + " and environment is : " + environment + " tags : " + tags);
        PropHolder.setEnvironment(environment);
        PropHolder.setBrowserName(browserName);
        ExcelHelper.getInstance();
        ConfigHelper.getInstance();
        logger.info("BaseRunner : @BeforeTest : setEnvDetails is complete");
    }
}
