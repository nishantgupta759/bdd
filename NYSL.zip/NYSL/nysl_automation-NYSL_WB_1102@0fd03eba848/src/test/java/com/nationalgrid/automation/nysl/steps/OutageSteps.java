package com.nationalgrid.automation.nysl.steps;
import org.openqa.selenium.support.PageFactory;

import com.nationalgrid.automation.nysl.actions.OutageActions;
import com.nationalgrid.automation.nysl.base.BaseInitialiser;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;


public class OutageSteps extends BaseInitialiser {
	
	OutageActions requestActions = PageFactory.initElements(driver, OutageActions.class);
	
	@Given("^User launch the application portal$")
	public void userLoadsApplicationPortal() throws Throwable {
		driver.get(configHelper.getConfigProperty("ApplicationUrl"));
	}

	@And("^User clicks continue Reporting Outage$")
	public void userClicksContinueReportingOutage() throws Throwable {
		requestActions.clickReportingOutageOptions();
	}

	@And("^User enters Address$")
	public void userEntersAddress() throws Throwable {
		requestActions.enterServiceAddress(testDataHelper.getDataMap().get("Address"));
	}
	
	@And("^User clicks on Search option$")
	public void userClicksOnSearchOption() throws Throwable {
		requestActions.clickAddressSearchOptions();
	}

	@And("^Verify if error message is displayed for invalid address$")
	public void validateErrorMessageForInvalidAddress() throws Throwable {
		requestActions.verifyErrorMessageForInvalidAddress(testDataHelper.getDataMap().get("AddressError"));
	}

	@And("^User clicks on any Green Light$")
	public void userClicksOnAnyGreenLight() throws Throwable {
		requestActions.clickGreenLightOptions();
	}

	@And("^User Clicks on Report this light$")
	public void userClicksOnReportThisLight() throws Throwable {
		requestActions.clickReportLightOptions();
	}
	
	@And("^Verify County id displayed$")
	public void VerifyCountyIdIsdisplayed() throws Throwable {
		requestActions.verifycounty();
	}
	
	@Then("^Verify Loading Assets text is displayed$")
	public void verifyLoadingAssetsTextIsDisplayed() throws Throwable {
		requestActions.verifyLoadingAssetsNotification();
	}

	@Then("^Verify if both Map View and Satellite View is displayed$")
	public void verifyIfBothMapViewAndSatelliteViewIsDisplayed() throws Throwable {
		requestActions.verifyMapView();
		requestActions.clickOnSatelliteView();
		requestActions.verifySatelliteView();
	}

	@Then("^Verify if default view is Map View$")
	public void verifyIfDefaultViewIsMapView() throws Throwable {
		requestActions.verifyMapView();
	}
	
	@Then("^Verify if \\+ sign and text 'Zoom in further to view the lights' is displayed$")
	public void verifyIfPlusSignAndTextZoomInFurtherToViewLightsIsDisplayed() throws Throwable {
		requestActions.verifyZoomPlusIcon();
		requestActions.verifyZoomInText();
	}

	@Then("^Verify if - sign and text 'Zoom Out' is displayed on hovering$")
	public void verifyIfMinusSignAndTextZoomOutIsDisplayedOnHovering() throws Throwable {
		requestActions.verifyZoomMinusIcon();
		requestActions.verifyZoomOutText();
	}

	@Then("^Verify if Arrow symbol is displayed$")
	public void verifyIfArrowSymbolIsDisplayed() throws Throwable {
		requestActions.verifyIfLocationPinIsDisplayed();
	}

	@Then("^Verify if hovering over Arrow 'Show my Location' text is displayed$")
	public void verifyIfHoveringOverArrowShowMyLocationTextIsDisplayed() throws Throwable {
		requestActions.mouseHoverOnLocationPin();
		requestActions.verifyIfLocationTextIsDisplayed();
	}
	
	@Then("^Verify if Box symbol is displayed and 'Map Overview' is displayed on hovering$")
	public void verifyIfHoveringOverBoxSymbolMapOverviewTextIsDisplayed() throws Throwable {
		requestActions.mouseHoverOnBoxIcon();
		requestActions.verifyIfMapOverviewTextIsDisplayed();
	}

	@Then("^Verify if user is presented with a web form to Report Outage$")
	public void verifyIfUserIsPresentedWithWebFormToReportOutage() throws Throwable {
		requestActions.clickOnReportThisLight();
		requestActions.verifyIfReportFormIsDisplayed();
	}
	
	@Then("^Verify if User is able to see Continue Reporting Outage$")
	public void verifyIfUserIsAbleToSeeContinueReportingOutage() throws Throwable {
		requestActions.verifyIfContinueReportingIsDisplayed();
	}

	@Then("^Verify if User is landed on map based outage reporting screen$")
	public void verifyIfUserIsLandedOnMapBasedOutageReportingScreen() throws Throwable {
		requestActions.verifyOutageMapPageUrl();
	}
	
	@Then("^Verify if User is landed on Report Outage Page$")
	public void verifyIfUserIsLandedOnReportOutagePage() throws Throwable {
	    requestActions.verifyOutageWarningPageUrl();
	}

	@Then("^Verify if Emergency Message is displayed$")
	public void verifyIfEmergencyMessageIsDisplayed() throws Throwable {
	    requestActions.validateEmergencyMesgLine1(testDataHelper.getDataMap().get("EmergencyMsgLine1"));
	    requestActions.validateEmergencyMesgLine2(testDataHelper.getDataMap().get("EmergencyMsgLine2"));
	    requestActions.validateEmergencyMesgLine3(testDataHelper.getDataMap().get("EmergencyMsgLine3"));
	}

	@Then("^Verify if Dos and Donts are displayed below the Emergency Message$")
	public void verifyIfDosAndDontsAreDisplayed() throws Throwable {
	   requestActions.validateDoesStep1(testDataHelper.getDataMap().get("DoesStep1"));
	   requestActions.validateDoesStep2(testDataHelper.getDataMap().get("DoesStep2"));
	   requestActions.validateDoesStep3(testDataHelper.getDataMap().get("DoesStep3"));
	   requestActions.validateDontsStep1(testDataHelper.getDataMap().get("DontsStep1"));
	   requestActions.validateDontsStep2(testDataHelper.getDataMap().get("DontsStep2"));
	   requestActions.validateDontsStep3(testDataHelper.getDataMap().get("DontsStep3"));
	}	
	
	@Then("^Verify if Reporting Heading is displayed$")
	public void verifyIfReportingHeadingIsDisplayed() throws Throwable {
		requestActions.verifyIfReportingHeadingIsDisplayed();
		requestActions.validateReportingHeadingText(testDataHelper.getDataMap().get("ReportingHeading"));
	}
	
	@Then("^Verify if Placeholder Text is displayed in Address bar$")
	public void verifyIfPlaceHolderTextIsDisplayed() throws Throwable {
		requestActions.verifyIfPlaceHolderTextIsDisplayed();
	}

	@Then("^Verify if Reporting steps are displayed$")
	public void verifyIfReportingStepsAreDisplayed() throws Throwable {
	    requestActions.verifyIfReportingStepsAreDisplayed();
	    requestActions.validateReportingStep1Text(testDataHelper.getDataMap().get("ReportingStep1"));
	    requestActions.validateReportingStep2Text(testDataHelper.getDataMap().get("ReportingStep2"));
	    requestActions.validateReportingStep3Text(testDataHelper.getDataMap().get("ReportingStep3"));
	}	
	
	@Then("^User Clicks on ZoomIn button$")
	public void userClicksOZoomInButton() throws Throwable {
	    requestActions.clickOnZoomPlus();
	}
	
	@Then("^Verify A Legend describing bulb colours is displayed$")
	public void verifyALegendDescribingBulbColoursIsDisplayed() throws Throwable {
	   requestActions.verifyIfMapLegendIsDisplayed();
	   requestActions.verifyWorkingLightIconAndText();
	   requestActions.verifyAdhocLightIconAndText();
	   requestActions.verifyReportedLightIconAndText();
	   requestActions.verifyNotOurLightIconAndText();
	}

	@Then("^Verify if assets are loaded on the Map as Bulbs$")
	public void verifyIfAssetsAreLoadedOnTheMapAsBulbs() throws Throwable {
	    requestActions.verifyGreenLights();
	}

	@Then("^Verify the Colour coding of the Bulbs on the Map$")
	public void verifyColourCodingOfBulbsTheMap() throws Throwable {
		requestActions.verifyAssetsOnMap();
	}
	
	@Then("^User clicks on Streelight breadcrumb$")
	public void userClicksOnStreetlightBreadcrumb() throws Throwable {
		requestActions.clickOnStreetlightBreadcrumb();
	}
	
	@Then("^User clicks on Outage Warning breadcrumb$")
	public void userClickOnOutageWarningBreadcrumb() throws Throwable {
		requestActions.clickOnOutageWarningBreadcrumb();
	}
	
	@Then("^Verify if error message is displayed when clicked on Show Location$")
	public void verifyErrorMessageOfShowLocation() throws Throwable {
		requestActions.verifyLoadingAssetsNotification();
		requestActions.clickOnShowLocation();
//		requestActions.verifyErrorMessageForInvalidAddress("We cannot determine your position at this location");
//		Manually we are seeing error, but through automation, its showing location pin
	}
	
}