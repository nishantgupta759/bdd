package com.nationalgrid.automation.nysl.locators;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.nationalgrid.automation.nysl.base.BaseInitialiser;

public class OutageLocators extends BaseInitialiser {

	@FindBy(xpath = "//button[contains(text(),'Outage')]")
	protected WebElement outageBtn;
	
	@FindBy(xpath = "//button[contains(text(),'Continue Reporting Outage')]")
	protected WebElement reportingOutage;
	
	@FindBy(xpath = "//input[@placeholder='Enter address nearest to light']")
	protected WebElement serviceAddress;
	
	@FindBy(xpath = "//*[local-name()='svg' and contains(@class,'search')]")
	protected WebElement addressSearchOpt;
	
	@FindBy(xpath = "//img[contains(@src,'LightBulbGreen')]")
	protected WebElement greenLightPole;
	//div[contains(@title,'XXX')]/img[contains(@src,'LightBulbGreen')]
	
	@FindBy(xpath = "//img[contains(@src,'')]")
	protected WebElement redLightPole;
	
	@FindBy(xpath = "//img[contains(@src,'')]")
	protected WebElement greyLightPole;
	
	@FindBy(xpath = "//span[contains(text(),'Report This Light')]")
	protected WebElement reportingLightOption;
	
	@FindBy(xpath = "//p[contains(text(),'Syracuse')]")
	protected WebElement county;
	
	@FindBy(xpath = "//img[@data-test='zoomPlus']")
	protected WebElement zoomPlusIcon;
	
	@FindBy(xpath = "//img[@data-test='zoomMinus']")
	protected WebElement zoomMinusIcon;
	
	@FindBy(xpath = "//div[@data-tooltip='Zoom in further to view the lights']")
	protected WebElement zoomInText;
	
	@FindBy(xpath = "//div[@data-tooltip='Map Zoom Out']")
	protected WebElement zoomOutText;
	
	@FindBy(xpath = "//div[@data-test='map-showmylocation']")
	protected WebElement myLocationIcon;
	
	@FindBy(xpath = "//div[@data-tooltip='Show my location']")
	protected WebElement myLocationText;
	
	@FindBy(xpath = "//div[contains(@class,'notification-map')]//div//p[contains(text(),'Loading of Assets')]")
	protected WebElement loadingAssetsNotification;
	
	@FindBy(xpath = "//div[@class='notification notification-warning notification-map']//div//p")
	protected WebElement errorAddressMesg;	
	
	@FindBy(xpath = "//span[contains(text(),'Map View')]")
	protected WebElement satelliteView;
	
	@FindBy(xpath = "//span[contains(text(),'Satellite View')]")
	protected WebElement mapView;
	
	@FindBy(xpath = "//img[@data-test='location']")
	protected WebElement locationPin;
	
	@FindBy(xpath = "//div[@class='icon-location-overview']//div//img")
	protected WebElement boxIcon;
	
	@FindBy(xpath = "//div[@data-tooltip='Show my location']")
	protected WebElement locationText;
	
	@FindBy(xpath = "//div[@class='icon-location-overview']//div")
	protected WebElement mapOverview;
	
	@FindBy(xpath = "//div[@id='myBtn']//span[contains(text(),'Report This Light')]")
	protected WebElement reportLight;
	
	@FindBy(xpath = "//form[@class='reporting-form']")
	protected WebElement reportForm;
	
	@FindBy(xpath = "//div[@class='buttonmodal']//span")
	protected WebElement reportLightBtn;
		
	@FindBy(xpath = "//h1[@class='report-outage__title']")
	protected WebElement reportHeading;

	@FindBy(xpath = "(//div[@class='instrction_content'])[1]")
	protected WebElement reportStep1;
	
	@FindBy(xpath = "//div[@class='instrction_content2']")
	protected WebElement reportStep2;
	
	@FindBy(xpath = "(//div[@class='instrction_content'])[2]")
	protected WebElement reportStep3;
	
	@FindBy(xpath = "//div[@class='report-outage__alert-message-content']//h3")
	protected WebElement reportStopMesg;
	
	@FindBy(xpath = "//div[@class='report-outage__alert-message-content']//h4")
	protected WebElement reportDamagedText;
	
	@FindBy(xpath = "//div[@class='report-outage__alert-message-content']//h5")
	protected WebElement reportContactText;
	
	@FindBy(xpath = "//div[@class='report-outage__alert-message-content']//h5//a")
	protected WebElement reportContactNum;
	
	@FindBy(xpath = "(//h3[contains(text(),'Do:')]//parent::div/ul/li)[1]")
	protected WebElement does1Text;
	
	@FindBy(xpath = "(//h3[contains(text(),'Do:')]//parent::div/ul/li)[2]")
	protected WebElement does2Text;
	
	@FindBy(xpath = "(//h3[contains(text(),'Do:')]//parent::div/ul/li)[3]")
	protected WebElement does3Text;
	
	@FindBy(xpath = "(//h3[contains(text(),'Don')]//parent::div/ul/li)[1]")
	protected WebElement dont1Text;
	
	@FindBy(xpath = "(//h3[contains(text(),'Don')]//parent::div/ul/li)[2]")
	protected WebElement dont2Text;
	
	@FindBy(xpath = "(//h3[contains(text(),'Don')]//parent::div/ul/li)[3]")
	protected WebElement dont3Text;
	
	@FindBy(xpath = "//div[@class='map-legend-container']")
	protected WebElement mapLegend;
	
	@FindBy(xpath = "(//div[@class='map-legend-container']//div[@class='notification-icon-wrap']//span)[1]")
	protected WebElement workingLightIcon;
	
	@FindBy(xpath = "(//div[@class='map-legend-container']//div[@class='notification-icon-wrap']//span)[2]")
	protected WebElement adhocReportIcon;
	
	@FindBy(xpath = "(//div[@class='map-legend-container']//div[@class='notification-icon-wrap']//span)[3]")
	protected WebElement reportedLightIcon;
	
	@FindBy(xpath = "(//div[@class='map-legend-container']//div[@class='notification-icon-wrap']//span)[4]")
	protected WebElement notOurLightIcon;
	
	@FindBy(xpath = "//div[@class='map-legend-container']//p[contains(text(),'Working Light')]")
	protected WebElement workingLightText;
	
	@FindBy(xpath = "//div[@class='map-legend-container']//p[contains(text(),'AD HOC Reporting')]")
	protected WebElement adhocReportText;
	
	@FindBy(xpath = "//div[@class='map-legend-container']//p[contains(text(),'Light Issue Reported')]")
	protected WebElement reportedLightText;
	
	@FindBy(xpath = "//div[@class='map-legend-container']//p[contains(text(),'Not Our Light')]")
	protected WebElement notOurLightText;
	
	@FindBy(xpath = "//div[@class='bread-crumbs']//a//p[contains(text(),'Streetlight Home')]")
	protected WebElement streetlightBreadcrumb;
	
	@FindBy(xpath = "//div[@class='bread-crumbs']//a//p[contains(text(),'Outage Warning')]")
	protected WebElement outageWarningBreadcrumb;
	
}