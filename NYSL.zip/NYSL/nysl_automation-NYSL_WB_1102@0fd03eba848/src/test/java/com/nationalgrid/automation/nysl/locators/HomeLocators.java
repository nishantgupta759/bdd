package com.nationalgrid.automation.nysl.locators;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.nationalgrid.automation.nysl.base.BaseInitialiser;

public class HomeLocators extends BaseInitialiser {

	@FindBy(xpath = "//div[@class='card nav-card']//child::span[text()='Street Light Outage']")
	protected WebElement streetLightOutageIcon;
	
	@FindBy(xpath = "//div[@class='card nav-card']//child::span[text()='Inventory']")
	protected WebElement inventoryIcon;
	
	@FindBy(xpath = "//div[@class='card nav-card']//child::span[text()='FAQs']")
	protected WebElement faqIcon;
	
	@FindBy(xpath = "//div[@class='card nav-card']//child::span[text()='Billing']")
	protected WebElement billingIcon;
	
	@FindBy(xpath = "//span[text()='Upstate NY Electric']//preceding::*[@class='icon icon-national-grid-logo']")
	protected WebElement nationalGridLogo;
	
	@FindBy(xpath = "//a[contains(@href,'/Contact-Us/FAQ')]")
	protected WebElement generalFAQsButton;
	
	@FindBy(xpath = "//a[@class='ngcw-main-navigation__logo']")
	protected WebElement contentPageNGLogo;
	
	@FindBy(xpath = "//p[text()='Copyright � 2020 National Grid USA Service Company, Inc. All rights reserved.']")
	protected WebElement copyrightInformation;
	
	@FindBy(xpath = "//span[text()='Contact Us']")
	protected WebElement contactUsLink;
	
	@FindBy(xpath = "//span[text()='Upstate NY Electric']")
	protected WebElement upstateNYElectric;
	
	@FindBy(xpath = "//span[text()='Go to nationalgridus.com']")
	protected WebElement goToNGLink;
	
	@FindBy(xpath = "//span[text()='Gas Emergencies']")
	protected WebElement gasEmergencyLink;
	
	@FindBy(xpath = "//span[text()='Power Outages']")
	protected WebElement powerOutagesLink;
	
}
