package com.nationalgrid.automation.nysl.locators;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.nationalgrid.automation.nysl.base.BaseInitialiser;

public class ReportFormPageLocators extends BaseInitialiser {

	@FindBy(xpath = "//label[@for='address']//following-sibling::input")
	protected WebElement addressInput;
	
	@FindBy(xpath = "//label[@for='pole-number']//following-sibling::input")
	protected WebElement poleNumInput;
	
	@FindBy(xpath = "//label[@for='pole-number']//*[contains(@class,'bubble')]")
	protected WebElement poleInfoBubble;

	@FindBy(xpath = "//div[@class='pole-number-legend']//p//following-sibling::img")
	protected WebElement polePopUp;
	
	@FindBy(xpath = "//label[@for='contact-name']//following-sibling::input")
	protected WebElement contactNameInput;
	
	@FindBy(xpath = "//label[@for='phone-number']//following-sibling::input")
	protected WebElement phoneNumberInput;
	
	@FindBy(xpath = "//label[@for='email-address']//following-sibling::input")
	protected WebElement emailInput;
	
	@FindBy(xpath = "//label[@for='contact-name']//following-sibling::small")
	protected WebElement contactNameError;
	
	@FindBy(xpath = "//label[@for='phone-number']//following-sibling::small")
	protected WebElement phoneNumberError;
	
	@FindBy(xpath = "//label[@for='email-address']//following-sibling::small")
	protected WebElement emailError;
	
	@FindBy(xpath = "//button[contains(text(),'Report')]")
	protected WebElement reportBtn;

	@FindBy(xpath = "//label[@for='comments']//following-sibling::textarea")
	protected WebElement commentsInput;
	
	@FindBy(xpath = "//label[@for='light-type']//following-sibling::select")
	protected WebElement lightTypeDropdown;
	
	@FindBy(xpath = "//label[@for='problem-type']//following-sibling::select")
	protected WebElement problemTypeDropdown;	
	
	@FindBy(xpath = "")
	protected WebElement cnfrmMesgText;
	
	@FindBy(xpath = "")
	protected WebElement continueToMapBtn;
	
}