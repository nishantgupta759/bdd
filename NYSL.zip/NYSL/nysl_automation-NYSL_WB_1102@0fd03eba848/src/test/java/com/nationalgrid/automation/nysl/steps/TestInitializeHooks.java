package com.nationalgrid.automation.nysl.steps;

import java.io.IOException;

import org.apache.log4j.Logger;

import com.nationalgrid.automation.nysl.base.BaseInitialiser;
import com.nationalgrid.automation.nysl.base.BrowserFactory;
import com.nationalgrid.automation.nysl.base.CustomReporter;
import com.nationalgrid.automation.nysl.utilities.DriverUtility;
import com.nationalgrid.automation.nysl.utilities.PropHolder;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;

public class TestInitializeHooks extends BaseInitialiser{
    
	private static Logger logger = Logger.getLogger(TestInitializeHooks.class);

    @Before
    public void beforeScenario(Scenario scenario) throws IOException {
    	String browserName = PropHolder.getBrowserName();
    	logger.info("TestInitializeHooks : Browser : " + browserName);

    	driver = BrowserFactory.createWebDriver(browserName);
    	driver.manage().deleteAllCookies();
        logger.info("Scenario: " + scenario.getName() + " started");
        CustomReporter.test = CustomReporter.extent.startTest(scenario.getName());
    }

    @After
    public void afterScenario(Scenario scenario) throws Exception {
        if (scenario.isFailed()) {
        	logger.error("Scenario: " + scenario.getName() + " failed");
            DriverUtility.attachSnapshotToReport();
            CustomReporter.flagResult("Fail", scenario.getName()+" failed unexpectedly", "", "yes");
        } else {
        	logger.info("Scenario: " + scenario.getName() + " passed");
        }
        BrowserFactory.destroyDriver();
    }
}
