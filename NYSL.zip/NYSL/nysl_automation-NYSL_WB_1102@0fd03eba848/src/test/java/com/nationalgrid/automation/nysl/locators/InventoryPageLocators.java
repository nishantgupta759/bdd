package com.nationalgrid.automation.nysl.locators;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.nationalgrid.automation.nysl.base.BaseInitialiser;

public class InventoryPageLocators extends BaseInitialiser {
	
	@FindBy(xpath = "//input[@id='signInName']")
	protected WebElement emailField;
	
	@FindBy(xpath = "//input[@id='password']")
	protected WebElement passwordField;
	
	@FindBy(xpath = "//button[contains(@class,'-primary sign-in') and contains(text(),'Sign In')]")
	protected WebElement signInField;
	
	@FindBy(xpath = "//button[@aria-label='Cancel and return to homepage']")
	protected WebElement cancelButton;
	
	@FindBy(xpath = "//button[@class='button  -primary reportselectlesslength']")
	protected WebElement selectAccountForMaster;
	
	@FindBy(xpath = "//button[@aria-label='Add Account']")
	protected WebElement addAccount;
	
	@FindBy(xpath = "(//button[@class='button  -primary reportselect'])[1]")
	protected WebElement selectAccountForReference;
	
	@FindBy(xpath = "//span[@class='masterAccount-body-firstcolumn']")
	protected WebElement accountNumbers;
	
	@FindBy(xpath = "//p[contains(text(),'Not a Streetlight Account')]")
	protected WebElement notAStreetlightAccount;
	
	@FindBy(xpath = "//img[@src='/static/media/Electric.4b0f949a.svg']")
	protected WebElement electricAccount;
	
	@FindBy(xpath = "//img[@src='/static/media/Gas.c3414134.svg']")
	protected WebElement gasAccount;
	
	@FindBy(xpath = "//h1[contains(text(),'Reference Numbers')]")
	protected WebElement referenceNumbersPageHeading;
	
	@FindBy(xpath = "//div[@class='loading-spinner']//span")
	protected WebElement loadingText;
	
	@FindBy(xpath = "//h1[contains(text(),'Inventory Report')]")
	protected WebElement inventoryReportPageHeading;
	
	@FindBy(xpath = "//li[@class='reference-li reference-acctName-content']//div//div")
	protected WebElement customerNameKey;
	
	@FindBy(xpath = "//li[@class='reference-li reference-acctName-content']//div//span")
	protected WebElement customerNameValue;
	
	@FindBy(xpath = "//li[@class='reference-li reference-acct-content']//div//div")
	protected WebElement masterAccountKey;
	
	@FindBy(xpath = "//li[@class='reference-li reference-acct-content']//div//span")
	protected WebElement masterAccountValue;
	
	@FindBy(xpath = "//li[@class='reference-li reference-mobile-view']//div//div")
	protected WebElement addressKey;
	
	@FindBy(xpath = "//li[@class='reference-li reference-mobile-view']//div//span")
	protected WebElement addressValue;
	
	@FindBy(xpath = "//div[@class='masterAccount-body-secondcolumn']")
	protected WebElement addressFieldOnAccountPage;
	
	@FindBy(xpath = "//input[@placeholder='Enter 10 digit account number without - or space']")
	protected WebElement searchForReferenceNumber;
	
	@FindBy(xpath = "//button[contains(text(),'Export')]")
	protected WebElement exportAllButtonRefPage;
	
	@FindBy(xpath = "//div[@class='reference-body-card']//parent::div//parent::div//input[@type='checkbox']")
	protected WebElement checkboxColRefPage;
	
	@FindBy(xpath = "//div[@class='reference-body-card']//parent::div//parent::div//span[@class='reference-body-firstcolumn']")
	protected WebElement referenceNumberColRefPage;
	
	@FindBy(xpath = "//div[@class='reference-body-card']//parent::div//parent::div//span[@class='reference-body-secondcolumn']")
	protected WebElement addressColRefPage;
	
	@FindBy(xpath = "//div[@class='reference-body-card']//parent::div//parent::div//div//button")
	protected WebElement viewCTAButtonRefPage;
	
	@FindBy(xpath = "//div[@class='pagination']//span//span")
	protected WebElement paginationTextRefPage;
	
	@FindBy(xpath = "(//div[@class='reference-body-card']//parent::div//parent::div//input[@type='checkbox'])[1]")
	protected WebElement firstCheckbox;
	
	@FindBy(xpath = "//a[@class='bread-link']//p[contains(text(),'Reference Numbers')]")
	protected WebElement referenceNumBreadcrumb;
	
	@FindBy(xpath = "//a[@class='bread-link']//p[contains(text(),'Account List')]")
	protected WebElement accountListBreadcrumb;
	
	@FindBy(xpath = "//a[@class='bread-link']//p[contains(text(),'Streetlight Home')]")
	protected WebElement streetLightBreadcrumb;
	
	@FindBy(xpath = "//a[@class='button -link-button -secondary back-button']")
	protected WebElement backButton;
	
	@FindBy(xpath = "//input[@name='checkAll']")
	protected WebElement checkBoxHeading;
	
	@FindBy(xpath = "//span[@class='reference-body-checkbox']//input")
	protected WebElement checkBoxes;
	
	@FindBy(xpath = "(//span[@class='reference-body-checkbox']//input)[1]")
	protected WebElement checkBox1;
	
	@FindBy(xpath = "(//span[@class='reference-body-checkbox']//input)[2]")
	protected WebElement checkBox2;
	
	@FindBy(xpath = "//div[@class='card reference-hidden-card']")
	protected WebElement modalPopUp;
	
	@FindBy(xpath = "//span[@class='ref-hidden-card-info']")
	protected WebElement accountsSelectedPopup;
	
	@FindBy(xpath = "//div[@class='card reference-hidden-card']//button")
	protected WebElement exportCSVPopup;
	
	@FindBy(xpath = "//div[@class='pagination']")
	protected WebElement pagination;
	
	@FindBy(xpath = "//div[@class='pagination']//a[contains(text(),'First')]")
	protected WebElement paginationFirstButton;
	
	@FindBy(xpath = "//div[@class='pagination']//a[contains(text(),'Next')]")
	protected WebElement paginationNextButton;
	
	@FindBy(xpath = "//div[@class='pagination']//a[contains(text(),'Prev')]")
	protected WebElement paginationPrevButton;
	
	@FindBy(xpath = "//div[@class='pagination']//a[contains(text(),'Last')]")
	protected WebElement paginationLastButton;
	
	@FindBy(xpath = "//button[@class='button  -secondary switch-to-map']")
	protected WebElement switchToMapView;
	
	@FindBy(xpath = "//div[@class='reportHeader']//parent::div//parent::div")
	protected WebElement tableView;
	
	@FindBy(xpath = "//span[contains(text(),'Location ID')]")
	protected WebElement locationID;
	
	@FindBy(xpath = "//span[contains(text(),'Pole No')]")
	protected WebElement poleNo;
	
	@FindBy(xpath = "//span[contains(text(),'Pole Suffix')]")
	protected WebElement poleSuffix;
	
	@FindBy(xpath = "//span[contains(text(),'Seq')]")
	protected WebElement seq;
	
	@FindBy(xpath = "//span[contains(text(),'Street Name')]")
	protected WebElement streetName;
	
	@FindBy(xpath = "//span[contains(text(),'Component Type')]")
	protected WebElement componentType;
	
	@FindBy(xpath = "//span[contains(text(),'Bill Code Title')]")
	protected WebElement billCodeTitle;
	
	@FindBy(xpath = "//span[contains(text(),'Light Status')]")
	protected WebElement lightStatus;
	
	@FindBy(xpath = "//span[contains(text(),'Source Type')]")
	protected WebElement sourceType;
	
	
}
