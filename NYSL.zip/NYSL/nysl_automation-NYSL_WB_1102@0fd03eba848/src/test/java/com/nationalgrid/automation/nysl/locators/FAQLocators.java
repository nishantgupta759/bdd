package com.nationalgrid.automation.nysl.locators;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.nationalgrid.automation.nysl.base.BaseInitialiser;

public class FAQLocators extends BaseInitialiser {
	
	@FindBy(xpath = "//h5[contains(text(),'�Opt-In� Luminaire Replacement Program')]")
	protected WebElement optInHeading;
	
	@FindBy(xpath = "//a[contains(@href,'opt-in-streetlight-replacement-form')]")
	protected WebElement optInLink;
	
	@FindBy(xpath = "//h4[contains(text(),'Assets Sales')]")
	protected WebElement assetSales;
	
	@FindBy(xpath = "//button[text()='      How to report a streetlight repair/outage?   ']")
	protected WebElement howToReportQ;
	
	@FindBy(xpath = "//a[contains(text(),'Streetlight Repair')]")
	protected WebElement streetlightRepairLink;
			
}
