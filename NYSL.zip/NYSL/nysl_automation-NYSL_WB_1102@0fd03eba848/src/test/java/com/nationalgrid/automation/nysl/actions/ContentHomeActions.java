package com.nationalgrid.automation.nysl.actions;

import com.nationalgrid.automation.nysl.locators.ContentHomeLocators;
import com.nationalgrid.automation.nysl.utilities.DriverUtility;

public class ContentHomeActions extends ContentHomeLocators {

	public void selectRegionNYUpstateHome() throws Exception {
		DriverUtility.clickElement(regionNewYork, "NewYork Region");
		DriverUtility.clickElement(locUpstate, "Upstate Location");
		DriverUtility.clickElement(typeHome, "Home");
	}
	
	public void selectRegionNYUpstateBusiness() throws Exception {
		DriverUtility.clickElement(regionNewYork, "NewYork Region");
		DriverUtility.clickElement(locUpstate, "Upstate Location");
		DriverUtility.clickElement(typeBusiness, "Business");
	}
	
	public void selectRegionMassachusettsElectricHome() throws Exception {
		DriverUtility.clickElement(regionMassachusetts, "Massachusetts");
		DriverUtility.clickElement(electric, "electric");
		DriverUtility.clickElement(typeHome, "Home");
	}
	
	public void confirmServiceLocation() throws Exception {
		DriverUtility.clickElement(cnfrmServiceLoc, "confirm service location");
	}

	public void verifySafetyOutageLink() throws Exception {
		DriverUtility.verifyElementIsDisplayed(safetyOutageBtn, "User verifies safety and outages option",
				"User verified safety and outages option", "User failed to verify safety and outages option");
	}
	
	public void mouseHoverOnSafetyOutageLink() throws Exception {
		DriverUtility.mouseOverUsingActions(safetyOutageBtn);
	}

	public void verifyStreetLightPortalLink() throws Exception {
		DriverUtility.verifyElementIsDisplayed(streetLightPortalLink, "User verfies Streetlight Portal link",
				"User verfied Streetlight Portal link", "User failed to verfiy Streetlight Portal link");
	}
	
	public void verifyStreetLightPortalLinkIsNotDisplayed() throws Exception {
		DriverUtility.verifyAbsenceOfElement(streetLightPortalLink, "User verfies Streetlight Portal link",
				"User verfied Streetlight Portal link", "User failed to verfiy Streetlight Portal link");
	}

	public void clickStreetLightPortalLink() throws Exception {
		DriverUtility.clickElement(streetLightPortalLink, "StreetLightPortal Link");
	}

	public void verifyFourIconContentPage() throws Exception {
		DriverUtility.verifyElementIsDisplayed(streetlightOutageLinkIcon, "User verifies Street Light Outage icon",
				"User verified Street Light Outage icon", "User failed to  verify Street Light Outage icon");
		DriverUtility.verifyElementIsDisplayed(streetlightInventoryLinkIcon, "User verifies Streetlight Inventory icon",
				"User verified Streetlight Inventory icon", "User failed to verify Streetlight Inventory icon");
		DriverUtility.verifyElementIsDisplayed(faqLinkIcon, "User verifies FAQs icon", "User verified FAQs icon",
				"User failed to verify FAQs icon");
		DriverUtility.verifyElementIsDisplayed(billingLinkIcon, "User verifies Billing icon",
				"User verified Billing icon", "User failed to  verify Billing icon");
	}

	public void verifyStreetLightPortalPageURL() throws Exception {
		DriverUtility.isURLContains("/Upstate-NY-Home/Streetlight-Portal/");
	}

	public void clickStreetLightInventoryLink() throws Exception {
		DriverUtility.clickElement(streetlightInventoryLinkIcon, "Inventory Link");
	}
	
	public void userSwitchesToNewWindow() throws Exception {
		DriverUtility.switchWindow();
	}
	
	public void clickInventoryLink() throws Exception {
		DriverUtility.clickElement(inventoryIcon, "Inventory Icon");
	}
	
	public void clickBillingLink() throws Exception {
		DriverUtility.clickElement(billingLinkIcon, "Billing Link");
	}

	public void verifyAzureIAMPageURL() throws Exception {
		DriverUtility.isURLContains("https://testloginnatinalgridus.b2clogin.com/");
	}
	
	public void verifyContactUsOption() throws Exception {
		DriverUtility.verifyElementIsDisplayed(contactUsOption, "User verfies contactUsOption",
				"User verfied contactUsOption", "User failed to verfiy contactUsOption");
	}
	
	public void clickContactUsOption() throws Exception {
		DriverUtility.clickElement(contactUsOption, "contactUsOption");
	}
	
	public void clickOnChangeLocation() throws Exception {
		DriverUtility.clickElement(changeLocation, "changeLocation");
	}

}