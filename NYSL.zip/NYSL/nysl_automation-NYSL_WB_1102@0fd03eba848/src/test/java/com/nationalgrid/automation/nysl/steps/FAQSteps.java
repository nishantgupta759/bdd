package com.nationalgrid.automation.nysl.steps;

import org.openqa.selenium.support.PageFactory;

import com.nationalgrid.automation.nysl.actions.FAQActions;
import com.nationalgrid.automation.nysl.base.BaseInitialiser;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;

public class FAQSteps extends BaseInitialiser {
	
	FAQActions requestActions = PageFactory.initElements(driver, FAQActions.class);

	@Then("^Verify if User is re-directed to FAQs page$")
	public void verifyIfUserIsRedirectedToFAQsPage() throws Throwable {
		requestActions.verifyFAQPageURL();
	}
	
	@Then("^Verify if Opt-In Luminare Replacement Program text is displayed$")
	public void verifyIfOptInLuminareReplacementProgramTextIsDisplayed() throws Throwable {
		requestActions.verifyIfOptInTextisDisplayed();
	}

	@Then("^Verify if Opt-In link is displayed under FAQs$")
	public void verifyIfOptInLinkIsDisplayedUnderFAQs() throws Throwable {
		requestActions.verifyOptInLinkisDisplayed();
	}
	
	@Then("^Click on Opt-In Link$")
	public void ClickOnOptInLink() throws Throwable {
		requestActions.clickOptInLink();
	}
	
	@Then("^Verify if Opt-In form is downloaded$")
	public void verifyIfOptInFormIsDownloadedS() throws Throwable {
		requestActions.verifyIfOptInFormIsdownloaded();	
	}

	@And("^Verify if Q&A for Asset sales are displayed$")
	public void verifyIfAssetSalesTextIsDisplayed() throws Throwable {
		requestActions.verifyAssetSalesText();	
	}
	
	@And("^Verify if How to Report a Streelight Repair/Outage Question is displayed$")
	public void verifyIfHowToReportAStreelightOutageQuestionIsDisplayed() throws Throwable {
		requestActions.verifyHowToReportStreelightOutageQuestion();	
	}
	
	@And("^User clicks on the question$")
	public void clickOnHowToReportAStreelightOutageQuestion() throws Throwable {
		requestActions.clickOnHowToReportStreelightOutageQuestion();	
	}
	
	@And("^verify if Streetlight repair link is displayed$")
	public void verifyIfStreetlightRepairLinkIsDisplayed() throws Throwable {
		requestActions.verifyStreelightRepairLinkIsDisplayed();
	}
	
	@And("^User clicks Streetlight repair link$")
	public void clickOnStreetlightRepairLink() throws Throwable {
		requestActions.clickOnStreelightRepairLink();
	}

}