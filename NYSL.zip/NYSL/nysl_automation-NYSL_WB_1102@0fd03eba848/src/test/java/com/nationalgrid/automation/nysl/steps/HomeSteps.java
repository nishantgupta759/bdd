package com.nationalgrid.automation.nysl.steps;

import org.openqa.selenium.support.PageFactory;

import com.nationalgrid.automation.nysl.actions.HomeActions;
import com.nationalgrid.automation.nysl.base.BaseInitialiser;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class HomeSteps extends BaseInitialiser {
	HomeActions homeActionsObj = PageFactory.initElements(driver, HomeActions.class);
	
	@Then("^User verifies Street Light Outage,Inventory,FAQ and Billing icon$")
	public void userVerifiesStreetLightOutageInventoryFAQBillingIcons () throws Throwable {
		homeActionsObj.verifyFourIcon();
	}
	
	@Then("^User verifies Nationalgrid logo$")
	public void userVerifiesNationalGridLogo () throws Throwable {
		homeActionsObj.verifyNationalGridLogo();
	}
	
	@Then("^User clicks Nationalgrid logo on HomePage$")
	public void userClicksOnNationalGridLogoOnHomePage () throws Throwable {
		homeActionsObj.clickNationalGridLogoOnHomePage();
	}
	
	@Then("^User verify General FAQs button$")
	public void userVerifiesGeneralFAQsButton () throws Throwable {
		homeActionsObj.verifyGeneralFAQsButton();
	}
	
	@Then("^User clicks on General FAQs$")
	public void userClicksOnGeneralFAQsButton () throws Throwable {
		homeActionsObj.clickOnGeneralFAQsButton();
	}
	
	@Then("^User verifies Upstate NY Electric text$")
	public void userVerifiesUpstateNYElectricText () throws Throwable {
		homeActionsObj.verifyUpstateNYElectric();
	}
	
	@Then("^User verifies Copyright Information$")
	public void userVerifiesCopyrightInformation () throws Throwable {
		homeActionsObj.verifyCopyrightInformation();
	}
	
	@Then("^User clicks Contact us link$")
	public void userClicksContactUsLink () throws Throwable {
		homeActionsObj.clickContactUsLink();
	}
	
	@Then("^User verifies Contact us page URL$")
	public void userVerifiesContactUsPageURL () throws Throwable {
		homeActionsObj.verifyContactUsPage();
	}
	
	@And("^User Clicks on Go to nationalgridus.com link$")
	public void userClicksOnGoToNationalGridLink () throws Throwable {
		homeActionsObj.clickOnNationalGridLink();
	}
	
	@When("^Verify if User is taken to NationalGrid Home Page$")
	public void verifyIfUserIsRedirectedToNationalGridHomePage () throws Throwable {
		homeActionsObj.verifyNationalGridHomePageUrl();
	}	
	
	@When("^User Clicks on Gas Emergencies link$")
	public void userClicksOnGasEmergenciesLink () throws Throwable {
		homeActionsObj.clickOnGasEmergenciesLink();
	}
	@When("^User Clicks on Power Outages link$")
	public void userClicksOnPowerOutagesLink () throws Throwable {
		homeActionsObj.clickOnPowerOutagesLink();
	}
	
	@When("^Verify if User is taken to Report a Gas Emergency Page$")
	public void verifyIfUserIsRedirectedToReportGasEmergencyPage () throws Throwable {
		homeActionsObj.verifyReportGasEmergencyPageUrl();
	}	
		
	@When("^Verify if User is taken to Report or Check an Outage Page$")
	public void verifyIfUserIsRedirectedToReportOrCheckAnOutagePage () throws Throwable {
		homeActionsObj.verifyReportAnOutagePageUrl();
	}
	
}
