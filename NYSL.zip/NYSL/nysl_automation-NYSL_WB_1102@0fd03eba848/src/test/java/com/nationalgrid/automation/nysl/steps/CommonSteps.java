package com.nationalgrid.automation.nysl.steps;

import java.util.Map;

import org.apache.log4j.Logger;

import com.nationalgrid.automation.nysl.base.BaseInitialiser;

import cucumber.api.java.en.Then;

public class CommonSteps extends BaseInitialiser {
	
	private static Logger logger = Logger.getLogger(CommonSteps.class);

	@Then("^testdata is loaded for the scenario (.*)$")
	public void testdata_is_loaded_for_the_scenario(String scenarioName) throws Throwable {
		Map<String, String> testData = testDataHelper.getDataForScenario(scenarioName.trim());
		logger.info("Data Map for : " + scenarioName + " is :" + testData);
	}
	
}