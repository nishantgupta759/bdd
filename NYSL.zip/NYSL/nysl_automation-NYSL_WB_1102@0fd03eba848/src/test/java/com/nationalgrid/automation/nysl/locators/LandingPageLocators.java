package com.nationalgrid.automation.nysl.locators;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.nationalgrid.automation.nysl.base.BaseInitialiser;

public class LandingPageLocators extends BaseInitialiser {

	@FindBy(xpath = "//h1[contains(text(),'Welcome to the Street Light Portal')]")
	protected WebElement landingPageHeading;
	
	@FindBy(xpath = "//button[contains(text(),'Outage')]")
	protected WebElement outageBtn;
	
	@FindBy(xpath = "//button[contains(text(),'FAQ')]")
	protected WebElement faqBtn;
	
}
