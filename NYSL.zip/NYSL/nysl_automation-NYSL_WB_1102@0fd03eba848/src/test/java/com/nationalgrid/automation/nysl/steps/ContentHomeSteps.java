package com.nationalgrid.automation.nysl.steps;

import org.openqa.selenium.support.PageFactory;

import com.nationalgrid.automation.nysl.actions.ContentHomeActions;
import com.nationalgrid.automation.nysl.base.BaseInitialiser;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ContentHomeSteps extends BaseInitialiser {
	ContentHomeActions contentHomeActionsObj = PageFactory.initElements(driver, ContentHomeActions.class);
	
	@When("^User Selects Region NY Upstate Home$")
	public void UserSelectsRegionNYUpstateHome() throws Throwable {
		contentHomeActionsObj.selectRegionNYUpstateHome();
	}
	
	@When("^User Selects Region NY Upstate Business$")
	public void UserSelectsRegionNYUpstateBusiness() throws Throwable {
		contentHomeActionsObj.selectRegionNYUpstateBusiness();
	}
	
	@And("^User clicks on Confirm Service Location$")
	public void userClicksOnConfirmServiceLocation() throws Throwable {
		contentHomeActionsObj.confirmServiceLocation();
	}
	
	@When("^User Selects Region Massachusetts Electric Home$")
	public void UserSelectsRegionMassachusettsElectricHome() throws Throwable {
		contentHomeActionsObj.selectRegionMassachusettsElectricHome();
	}
	
	@Given("^User launch the content application portal$")
	public void userLaunchContentApplicationPortal() throws Throwable {
		driver.get(configHelper.getConfigProperty("ApplicationContentPageUrl"));
	}
	
	@Then("^User verifies safety and outages option$")
	public void userVerifiesSafetyAndOutagesOption() throws Throwable {
		contentHomeActionsObj.verifySafetyOutageLink();
	}
	
	@And("^User clicks safety and outages option$")
	public void userClicksSafetyAndOutagesOption() throws Throwable {
		contentHomeActionsObj.mouseHoverOnSafetyOutageLink();
	}
	
	@Then("^User verfies Streetlight Portal link$")
	public void userVerifiesStreetLightPortalLink() throws Throwable {
		contentHomeActionsObj.verifyStreetLightPortalLink();
	}
	
	@Then("^Verify Streetlight Portal link should not be displayed$")
	public void verifyStreetlightPortalLinkShouldNotBeDisplayed() throws Throwable {
		contentHomeActionsObj.verifyStreetLightPortalLinkIsNotDisplayed();
	}
	
	@Then("^User clicks Streetlight Portal link$")
	public void user_clicksStreetlightPortalLink() throws Throwable {
		contentHomeActionsObj.clickStreetLightPortalLink();
	}
	
	@Then("^User verifies Street Light Outage,Streetlight Inventory,FAQs and Billing icon$")
	public void userVerifiesStreetLightLandingPageIcons() throws Throwable {
		contentHomeActionsObj.verifyFourIconContentPage();
	}
	
	@Then("^User verifies Street Light Landing Page$")
	public void userVerifiesStreetLightLandingPageUrl() throws Throwable {
	    contentHomeActionsObj.verifyStreetLightPortalPageURL();
	}

	@Then("^User clicks on Inventory button$")
	public void userClicksOnInventoryButton() throws Throwable {
		contentHomeActionsObj.clickInventoryLink();
	}
	
	@Then("^User clicks on StreelightInventory button$")
	public void userClicksOnStreelightInventoryButton() throws Throwable {
		contentHomeActionsObj.clickStreetLightInventoryLink();
	}
	
	@Then("^User Switches to new window$")
	public void userSwitchesToNewWindow() throws Throwable {
		contentHomeActionsObj.userSwitchesToNewWindow();
		Thread.sleep(6000);
	}
	
	@And("^User clicks on Billing Icon$")
	public void userClicksOnBillingButton() throws Throwable {
	   contentHomeActionsObj.clickBillingLink();
	}

	@Then("^Verify if User is redirected to Azure IAM Portal for Login$")
	public void verifyIfUserIsRedirectedToAzureIAMPortal() throws Throwable {
		contentHomeActionsObj.verifyAzureIAMPageURL();
	}
	
	@Then("^User verifies Contact Us option$")
	public void userVerifiesContactUsOption() throws Throwable {
	    contentHomeActionsObj.verifyContactUsOption();
	}

	@Then("^Clicks on Contact Us option$")
	public void clicksOnContactUsOption() throws Throwable {
		contentHomeActionsObj.clickContactUsOption();
	}
	
	@Then("^User clicks on Change Location$")
	public void clicksOnChangeLocation() throws Throwable {
	    contentHomeActionsObj.clickOnChangeLocation();
	}
	
}