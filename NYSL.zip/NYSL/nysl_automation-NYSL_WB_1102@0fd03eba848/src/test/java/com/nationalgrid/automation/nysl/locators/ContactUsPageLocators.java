package com.nationalgrid.automation.nysl.locators;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.nationalgrid.automation.nysl.base.BaseInitialiser;

public class ContactUsPageLocators extends BaseInitialiser {
	
	@FindBy(xpath = "//div[@class='tile-group__tiles']//a[contains(text(),'Streetlight Outage')]")
	protected WebElement streetLightOutage;
	
	@FindBy(xpath = "//h3[contains(text(),'Email Us')]")
	protected WebElement emailUs; 
    
}