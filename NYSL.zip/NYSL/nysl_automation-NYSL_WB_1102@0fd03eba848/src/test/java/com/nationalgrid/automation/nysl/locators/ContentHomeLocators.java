package com.nationalgrid.automation.nysl.locators;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.nationalgrid.automation.nysl.base.BaseInitialiser;

public class ContentHomeLocators extends BaseInitialiser {
	@FindBy(xpath = "(//h3[contains(text(),'New York')])//parent::button[1]")
	protected WebElement regionNewYork;
	
	@FindBy(xpath = "(//h3[contains(text(),'Massachusetts')])//parent::button[1]")
	protected WebElement regionMassachusetts;

	@FindBy(xpath = "//h3[text()='Upstate']//parent::button")
	protected WebElement locUpstate;
	
    @FindBy(xpath = "//h3[text()='Electric']//parent::button")
	protected WebElement electric;
     
    @FindBy(xpath = "//*[text()='Home']//parent::a")
    protected WebElement typeHome;

    @FindBy(xpath = "//*[text()='Business']//parent::a")
	protected WebElement typeBusiness;

    @FindBy(xpath = "(//nav[@id='main-navigation']/ul/li)[4]/button")
    protected WebElement safetyOutageBtn;
    
    @FindBy(xpath = "//a[@class='button -link-sub ngcw-main-navigation__primary-link' and text()='Streetlight Portal']")
	protected WebElement streetLightPortalLink;
    
    @FindBy(xpath = "//a[text()='Streetlight Outage']")
	protected WebElement streetlightOutageLinkIcon;
    
    @FindBy(xpath = "//a[text()='Streetlight Inventory']")
    protected WebElement streetlightInventoryLinkIcon;
    
    @FindBy(xpath = "//button[text()='Inventory']")
	protected WebElement inventoryIcon;
    
    @FindBy(xpath = "//a[text()='FAQs']")
	protected WebElement faqLinkIcon;
    
    @FindBy(xpath = "//a[text()='Billing']")
    protected WebElement billingLinkIcon;
    
    @FindBy(xpath = "//span[contains(text(),'Confirm Service Location')]//parent::button")
    protected WebElement cnfrmServiceLoc;
    
    @FindBy(xpath = "//div[@class='ngcw-main-navigation__utility-actions']//a[contains(text(),'Contact Us')]")
    protected WebElement contactUsOption;
    
    @FindBy(xpath = "//span[@class='button -icon-text -small ngcw-main-navigation__region-change']")
	protected WebElement changeLocation;
    
}