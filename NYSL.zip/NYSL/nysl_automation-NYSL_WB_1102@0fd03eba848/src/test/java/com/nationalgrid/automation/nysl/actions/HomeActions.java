package com.nationalgrid.automation.nysl.actions;

import com.nationalgrid.automation.nysl.locators.HomeLocators;
import com.nationalgrid.automation.nysl.utilities.DriverUtility;


public class HomeActions extends HomeLocators {

	public void verifyFourIcon() throws Exception {
		DriverUtility.verifyElementIsDisplayed(streetLightOutageIcon, "User verifies Street Light Outage icon", "User verified Street Light Outage icon", "User failed to verify Street Light Outage icon");
		DriverUtility.verifyElementIsDisplayed(inventoryIcon, "User verifies Inventory icon", "User verified Inventory icon", "User failed to verify Inventory icon");
		DriverUtility.verifyElementIsDisplayed(faqIcon, "User verifies FAQs icon", "User verified FAQs icon", "User failed to verify FAQs icon");
		DriverUtility.verifyElementIsDisplayed(billingIcon, "User verifies Billing icon", "User verified Billing icon" , "User failed to  verify Billing icon");
	}
	
	public void verifyNationalGridLogo() throws Exception {
		DriverUtility.verifyElementIsDisplayed(nationalGridLogo, "User verifies Nationalgrid logo", "User verified Nationalgrid logo", "User failed to verify Nationalgrid logo");
	}
	
	public void verifyGeneralFAQsButton() throws Exception {
		DriverUtility.verifyElementIsDisplayed(generalFAQsButton, "User verifies generalFAQsButton", 
				"User verified generalFAQsButton", "User failed to verify generalFAQsButton");
	}
	
	public void clickOnGeneralFAQsButton() throws Exception {
		DriverUtility.clickElement(generalFAQsButton, "clickElement");
	}
	
	public void clickNationalGridLogoOnHomePage() throws Exception {
		DriverUtility.clickElement(contentPageNGLogo, "contentPageNGLogo");
	}
	
	public void verifyUpstateNYElectric() throws Exception {
		DriverUtility.verifyElementIsDisplayed(upstateNYElectric, "User verifies upstateNYElectric", "User verified upstateNYElectric", "User failed to verify upstateNYElectric");
	}
	
	public void verifyCopyrightInformation() throws Exception {
		DriverUtility.verifyElementIsDisplayed(copyrightInformation, "User verifies Copyright Information", "User verified Copyright Information", "User failed to  verify Copyright Information");
	}
	
	public void clickContactUsLink() throws Exception{
		DriverUtility.clickElement(contactUsLink, "Contact Us link");
	}
	
	public void verifyContactUsPage() throws Exception{
		DriverUtility.isURLContains("Upstate-NY-Home/Contact-Us/");
	}
	
	public void verifyNationalGridHomePageUrl() throws Exception{
		DriverUtility.isURLContains("https://www.nationalgridus.com/Upstate-NY-Home/Default.aspx");
	}
	
	public void clickOnNationalGridLink() throws Exception{
		DriverUtility.clickElement(goToNGLink, "go to Nationalgrid.com link");
	}
	
	public void verifyReportGasEmergencyPageUrl() throws Exception{
		DriverUtility.isURLContains("/Natural-Gas-Safety/Report-a-Gas-Emergency");
	}
	
	public void clickOnGasEmergenciesLink() throws Exception{
		DriverUtility.clickElement(gasEmergencyLink, "Gas emergencies link");
	}
	
	public void verifyReportAnOutagePageUrl() throws Exception{
		DriverUtility.isURLContains("https://test-us.nationalgridus.com/outages");
	}
	
	public void clickOnPowerOutagesLink() throws Exception{
		DriverUtility.clickElement(powerOutagesLink, "powerOutagesLink link");
	}
	
}
