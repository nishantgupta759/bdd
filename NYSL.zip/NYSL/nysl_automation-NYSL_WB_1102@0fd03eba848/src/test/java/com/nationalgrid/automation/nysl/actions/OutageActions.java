package com.nationalgrid.automation.nysl.actions;

import com.nationalgrid.automation.nysl.locators.OutageLocators;
import com.nationalgrid.automation.nysl.utilities.DriverUtility;
import com.nationalgrid.automation.nysl.utilities.JavascriptUtility;

public class OutageActions extends OutageLocators {

	public void clickOutageOptions() throws Exception {
		DriverUtility.clickElement(outageBtn, "Outage Button");
	}

	public void clickReportingOutageOptions() throws Exception {
		DriverUtility.clickElement(reportingOutage, "Continue reporting Outage");
	}
	
	public void enterServiceAddress(String value) throws Exception {
		JavascriptUtility.scrollToElementUsingJS(serviceAddress);
		DriverUtility.sendText(serviceAddress, value, "service Address");
	}
	
	public void clickAddressSearchOptions() throws Exception {
		DriverUtility.clickElement(addressSearchOpt, "Address search option");
	}
	
	public void verifyErrorMessageForInvalidAddress(String value) throws Exception {
		DriverUtility.verifyElementText(errorAddressMesg, value, "verify errorAddressMesg", "verified errorAddressMesg", "Unable to verify errorAddressMesg");
	}
	
	public void verifyGreenLights() throws Exception {
		DriverUtility.verifyElementIsDisplayed(greenLightPole, "verify greenLightPole", "verified greenLightPole", "Unable to verify the greenLightPole");
	}
	
	public void verifyAssetsOnMap() throws Exception {
		DriverUtility.verifyElementIsDisplayed(greenLightPole, "verify greenLightPole", "verified greenLightPole", "Unable to verify the greenLightPole");
		DriverUtility.verifyElementIsDisplayed(redLightPole, "verify greenLightPole", "verified greenLightPole", "Unable to verify the greenLightPole");
		DriverUtility.verifyElementIsDisplayed(greyLightPole, "verify greenLightPole", "verified greenLightPole", "Unable to verify the greenLightPole");
	}
	
	public void clickGreenLightOptions() throws Exception {
		DriverUtility.clickElement(greenLightPole, "Green light Pole");
	}
	
	public void clickReportLightOptions() throws Exception {
		DriverUtility.clickElement(reportingLightOption, "Reporting light Option");
	}
	
	public void clickOnZoomPlus() throws Exception {
		DriverUtility.clickElement(zoomPlusIcon, "zoomPlusIcon");
	}

	public void verifycounty() throws Exception {
		DriverUtility.verifyElementIsDisplayed(county, "verify county", "verified County", "Unable to verify the County");
	}
	
	public void verifyZoomPlusIcon() throws Exception {
		DriverUtility.verifyElementIsDisplayed(zoomPlusIcon, "verify zoomPlusIcon", "verified zoomPlusIcon", "Unable to verify zoomPlusIcon");
	}
	
	public void verifyZoomMinusIcon() throws Exception {
		DriverUtility.verifyElementIsDisplayed(zoomMinusIcon, "verify zoomMinusIcon", "verified zoomMinusIcon", "Unable to verify zoomMinusIcon");
	}
	
	public void verifyZoomInText() throws Exception {
		DriverUtility.verifyElementIsDisplayed(zoomInText, "verify zoomInText", "verified zoomInText", "Unable to verify zoomInText");
	}
	
	public void verifyZoomOutText() throws Exception {
		DriverUtility.verifyElementIsDisplayed(zoomOutText, "verify zoomOutText", "verified zoomOutText", "Unable to verify zoomOutText");
	}
	
	public void verifyMyLocationIcon() throws Exception {
		DriverUtility.verifyElementIsDisplayed(myLocationIcon, "verify myLocationIcon", "verified myLocationIcon", "Unable to verify myLocationIcon");
	}
	
	public void verifyMyLocationText() throws Exception {
		DriverUtility.verifyElementIsDisplayed(myLocationText, "verify myLocationText", "verified myLocationText", "Unable to verify myLocationText");
	}
	
	public void verifyLoadingAssetsNotification() throws Exception {
		JavascriptUtility.scrollToElementUsingJS(loadingAssetsNotification);
		DriverUtility.verifyElementIsDisplayed(loadingAssetsNotification, "verify loadingAssetsNotification", "verified loadingAssetsNotification", "Unable to verify loadingAssetsNotification");
	}
	
	public void verifySatelliteView() throws Exception {
		DriverUtility.verifyElementIsDisplayed(satelliteView, "verify satelliteView", "verified satelliteView", "Unable to verify satelliteView");
	}
	
	public void clickOnSatelliteView() throws Exception {
		DriverUtility.clickElement(mapView, "satelliteView");
	}
	
	public void verifyMapView() throws Exception {
		JavascriptUtility.scrollToElementUsingJS(mapView);
		DriverUtility.verifyElementIsDisplayed(mapView, "verify MapView", "verified MapView", "Unable to verify MapView");
	}
	
	public void verifyIfLocationPinIsDisplayed() throws Exception {
		DriverUtility.verifyElementIsDisplayed(locationPin, "verify locationPin", "verified locationPin", "Unable to verify locationPin");
	}
	
	public void mouseHoverOnLocationPin() throws Exception {
		DriverUtility.mouseOverUsingActions(locationPin);
	}
	
	public void mouseHoverOnBoxIcon() throws Exception {
		DriverUtility.mouseOverUsingActions(boxIcon);
	}
	
	public void verifyIfLocationTextIsDisplayed() throws Exception {
		DriverUtility.verifyElementIsDisplayed(locationText, "verify LocationText", "verified LocationText", "Unable to verify LocationText");
	}
	
	public void verifyIfMapOverviewTextIsDisplayed() throws Exception {
		DriverUtility.verifyElementIsDisplayed(mapOverview, "verify mapOverview", "verified mapOverview", "Unable to verify mapOverview");
	}
	
	public void verifyIfReportFormIsDisplayed() throws Exception {
		DriverUtility.verifyElementIsDisplayed(reportForm, "verify reportForm", "verified reportForm", "Unable to verify reportForm");
	}

	public void clickOnReportThisLight() throws Exception {
		DriverUtility.clickElement(reportLightBtn, "reportLightBtn");
	}
	
	public void verifyIfContinueReportingIsDisplayed() throws Exception {
		DriverUtility.verifyElementIsDisplayed(reportingOutage, "verify reportingOutage", "verified reportingOutage", "Unable to verify reportingOutage");
	}
	
	public void verifyOutageMapPageUrl() throws Exception {
		DriverUtility.isURLContains("/OutageWarning/OutageMap");
	}
	
	public void verifyOutageWarningPageUrl() throws Exception {
		DriverUtility.isURLContains("/OutageWarning");
	}
	
	public void verifyIfWarningMessageIsDisplayed() throws Exception {
		DriverUtility.verifyElementIsDisplayed(reportingOutage, "verify reportingOutage", "verified reportingOutage", "Unable to verify reportingOutage");
	}
	
	public void verifyIfReportingHeadingIsDisplayed() throws Exception {
		DriverUtility.verifyElementIsDisplayed(reportHeading, "verify reportHeading", "verified reportHeading", "Unable to verify reportHeading");
	}
	
	public void verifyIfPlaceHolderTextIsDisplayed() throws Exception {
		DriverUtility.verifyElementIsDisplayed(serviceAddress, "verify placeholderText", "verified placeholderText", "Unable to verify placeholderText");
	}

	public void verifyIfReportingStepsAreDisplayed() throws Exception {
		DriverUtility.verifyElementIsDisplayed(reportStep1, "verify reportStep1", "verified reportStep1", "Unable to verify reportStep1");
		DriverUtility.verifyElementIsDisplayed(reportStep2, "verify reportStep2", "verified reportStep2", "Unable to verify reportStep2");
		DriverUtility.verifyElementIsDisplayed(reportStep3, "verify reportStep3", "verified reportStep3", "Unable to verify reportStep3");
	}
	
	public void validateReportingHeadingText (String value) throws Exception {
		DriverUtility.verifyElementText(reportHeading, value, "verify reportHeading", "verified reportHeading", "Unable to verify reportHeading");
	}
	
	public void validateReportingStep1Text (String value) throws Exception {
		DriverUtility.verifyElementText(reportStep1, value, "verify reportStep1", "verified reportStep1", "Unable to verify reportStep1");
	}
	
	public void validateReportingStep2Text (String value) throws Exception {
		DriverUtility.verifyElementText(reportStep2, value, "verify reportStep2", "verified reportStep2", "Unable to verify reportStep2");
	}
	
	public void validateReportingStep3Text (String value) throws Exception {
		DriverUtility.verifyElementText(reportStep3, value, "verify reportStep3", "verified reportStep3", "Unable to verify reportStep3");
	}
	
	public void validateEmergencyMesgLine1 (String value) throws Exception {
		DriverUtility.verifyElementText(reportStopMesg, value, "verify reportStopMesg", "verified reportStopMesg", "Unable to verify reportStopMesg");
	}
	
	public void validateEmergencyMesgLine2 (String expText) throws Exception {
		DriverUtility.verifyElementText(reportDamagedText, expText, "verify reportDamagedText", "verified reportDamagedText", 
				"Unable to verify reportDamagedText");
	}
	
	public void validateEmergencyMesgLine3 (String expText) throws Exception {
		DriverUtility.verifyElementText(reportContactText, expText, "verify reportContactText", "verified reportContactText", 
				"Unable to verify reportContactText");
	}
	
	public void validateDoesStep1 (String expText) throws Exception {
		DriverUtility.verifyElementText(does1Text, expText, "verify does1Text", "verified does1Text", 
				"Unable to verify does1Text");
	}
	
	public void validateDoesStep2 (String expText) throws Exception {
		DriverUtility.verifyElementText(does2Text, expText, "verify does2Text", "verified does2Text", 
				"Unable to verify does2Text");
	}
	
	public void validateDoesStep3 (String expText) throws Exception {
		DriverUtility.verifyElementText(does3Text, expText, "verify does3Text", "verified does3Text", 
				"Unable to verify does3Text");
	}
	
	public void validateDontsStep1 (String expText) throws Exception {
		DriverUtility.verifyElementText(dont1Text, expText, "verify dont1Text", "verified dont1Text", 
				"Unable to verify if dont1Text");
	}
	
	public void validateDontsStep2 (String expText) throws Exception {
		DriverUtility.verifyElementText(dont2Text, expText, "verify dont2Text", "verified dont2Text", 
				"Unable to verify if dont2Text");
	}
	
	public void validateDontsStep3 (String expText) throws Exception {
		DriverUtility.verifyElementText(dont3Text, expText, "verify dont3Text", "verified dont3Text", 
				"Unable to verify if dont3Text");
	}
	
	public void verifyIfMapLegendIsDisplayed () throws Exception {
		DriverUtility.verifyElementIsDisplayed(mapLegend, "verify mapLegend", "verified mapLegend", 
				"Unable to verify if mapLegend");
	}
	
	public void verifyWorkingLightIconAndText () throws Exception {
		DriverUtility.verifyElementIsDisplayed(workingLightIcon, "verify workingLightIcon", "verified workingLightIcon", 
				"Unable to verify if workingLightIcon");
		DriverUtility.verifyElementIsDisplayed(workingLightText, "verify workingLightText", "verified workingLightText", 
				"Unable to verify if workingLightText");
	}
	
	public void verifyAdhocLightIconAndText () throws Exception {
		DriverUtility.verifyElementIsDisplayed(adhocReportIcon, "verify adhocReportIcon", "verified adhocReportIcon", 
				"Unable to verify if adhocReportIcon");
		DriverUtility.verifyElementIsDisplayed(adhocReportText, "verify adhocReportText", "verified adhocReportText", 
				"Unable to verify if adhocReportText");
	}
	
	public void verifyReportedLightIconAndText () throws Exception {
		DriverUtility.verifyElementIsDisplayed(reportedLightIcon, "verify reportedLightIcon", "verified reportedLightIcon", 
				"Unable to verify if reportedLightIcon");
		DriverUtility.verifyElementIsDisplayed(reportedLightText, "verify reportedLightText", "verified reportedLightText", 
				"Unable to verify if reportedLightText");
	}
	
	public void verifyNotOurLightIconAndText () throws Exception {
		DriverUtility.verifyElementIsDisplayed(notOurLightIcon, "verify notOurLightIcon", "verified notOurLightIcon", 
				"Unable to verify if notOurLightIcon");
		DriverUtility.verifyElementIsDisplayed(notOurLightText, "verify notOurLightText", "verified notOurLightText", 
				"Unable to verify if notOurLightText");
	}
	
	public void clickOnShowLocation() throws Exception {
		DriverUtility.clickElement(locationPin, "locationPin");
	}
	
	public void clickOnStreetlightBreadcrumb() throws Exception {
		DriverUtility.clickElement(streetlightBreadcrumb, "streetlightBreadcrumb");
	}
	
	public void clickOnOutageWarningBreadcrumb() throws Exception {
		DriverUtility.clickElement(outageWarningBreadcrumb, "outageWarningBreadcrumb");
	}
	
}