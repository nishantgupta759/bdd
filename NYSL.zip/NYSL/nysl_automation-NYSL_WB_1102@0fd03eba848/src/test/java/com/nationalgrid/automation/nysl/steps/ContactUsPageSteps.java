package com.nationalgrid.automation.nysl.steps;

import org.openqa.selenium.support.PageFactory;

import com.nationalgrid.automation.nysl.actions.ContactUsPageActions;
import com.nationalgrid.automation.nysl.base.BaseInitialiser;

import cucumber.api.java.en.Then;

public class ContactUsPageSteps extends BaseInitialiser {
	ContactUsPageActions requestActionsObj = PageFactory.initElements(driver, ContactUsPageActions.class);
	
	@Then("^User verifies Email Us option$")
	public void userVerifiesEmailUsOption() throws Throwable {
		requestActionsObj.verifyEmailUsOption();
	}

	@Then("^User verifies StreetLight outage link$")
	public void userVerifiesStreetLightOutageLink() throws Throwable {
		requestActionsObj.verifyStreetLightOutage();
	}

	@Then("^click on StreetLight Outage link$")
	public void clickOnStreetLightOutageLink() throws Throwable {
		requestActionsObj.clickOnStreetLightOutage();
	}

	@Then("^User verifies StreetLight portal url$")
	public void userVerifiesStreetLightportalUrl() throws Throwable {
	    requestActionsObj.verifyStreetLightPageURL();
	}
	
}