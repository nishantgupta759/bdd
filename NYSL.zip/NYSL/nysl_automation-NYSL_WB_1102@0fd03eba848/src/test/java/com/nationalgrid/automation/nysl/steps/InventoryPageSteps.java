package com.nationalgrid.automation.nysl.steps;

import org.openqa.selenium.support.PageFactory;

import com.nationalgrid.automation.nysl.actions.InventoryPageActions;
import com.nationalgrid.automation.nysl.base.BaseInitialiser;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;

public class InventoryPageSteps extends BaseInitialiser {
	
	InventoryPageActions requestActions = PageFactory.initElements(driver, InventoryPageActions.class);

	@And("^User enters Login details$")
	public void userEntersLoginDetails() throws Throwable {
		requestActions.userEntersEmailId(testDataHelper.getDataMap().get("EmailId"));
		requestActions.userEntersPassword(testDataHelper.getDataMap().get("Password"));
	}
	
	@And("^User clicks on Login$")
	public void userClicksOnLoginButton() throws Throwable {
		requestActions.userClicksOnSignInButton();
		Thread.sleep(5000);
	}
	
	@Then("^Verify if Loading is displayed$")
	public void verifyIfLoadingIsDisplayed() throws Throwable {
		requestActions.verifyIfLoadingIsDisplayed();
	}
	
	@Then("^Verify if user is landed on Account selection page$")
	public void verifyIfUserIsLandedOnAccountSelectionPage() throws Throwable {
		requestActions.verifyAccountSelectionPageUrl();
	}
	
	@And("^User clicks on Cancel button$")
	public void userClicksOnCancelButton() throws Throwable {
		requestActions.clickOnCancelButton();
	}
	
	@And("^Verify if Master or Reference accounts have Select Account button$")
	public void verifyIfMasterOrReferenceAccountsHaveSelectAccountButton() throws Throwable {
		requestActions.verifyIfMasterAccountsHaveSelectAccountButton();
		requestActions.verifyIfReferenceAccountsHaveSelectAccountButton();
	}
	
	@And("^Verify if Account Numbers are displayed$")
	public void verifyIfAccountNumbersAreDisplayed() throws Throwable {
		requestActions.verifyIfAccountNumbersColumnIsDisplayed();
	}
	
	@And("^Verify if the Accounts are grouped according to Master, Reference and Ineligibility criteria$")
	public void verifyIfAccountsAreGroupedAccordingToMasterReferenceAndIneliibilityCriteria() throws Throwable {
		requestActions.verifyIfMasterAccountsHaveSelectAccountButton();
		requestActions.verifyIfReferenceAccountsHaveSelectAccountButton();
		requestActions.verifyIfInEligibilityAccountIsDisplayed();
	}
	
	@And("^Verify if Ineligibility accounts are listed with message Not a Streelight Account$")
	public void verifyIfIneligibilityAccountsAreListedWithMessageNotAStreelightAccount() throws Throwable {
		requestActions.verifyIfInEligibilityAccountIsDisplayed();
	}
	
	@And("^Verify if Electric accounts are displayed$")
	public void verifyIfElectricAccountsAreListedWithMessageNotAStreelightAccount() throws Throwable {
		requestActions.verifyIfElectricAccountIsDisplayed();
	}
	
	@And("^Verify if Gas accounts are displayed$")
	public void verifyIfGasAccountsAreListedWithMessageNotAStreelightAccount() throws Throwable {
		requestActions.verifyIfGasAccountIsDisplayed();
	}
	
	@And("^User clicks on Select Account button for Master$")
	public void userClicksOnSelectAccountButtonForMaster() throws Throwable {
		requestActions.clickOnSelectAccountButtonForMaster();
	}
	
	@And("^User clicks on Select Account button for Reference Account$")
	public void userClicksOnSelectAccountButtonForReferenceAccount() throws Throwable {
		requestActions.clickOnSelectAccountButtonForReferenceAccount();
	}
	
	@And("^Verify if user is landed on Reference Numbers page$")
	public void verifyUserIsLandedOnReferenceNumbersPage() throws Throwable {
		requestActions.verifyAccountSelectionPageUrl();
		requestActions.verifyReferenceNumbersPageHeading();
	}
	
	@And("^Verify if Account Name, Master Account Number and Communication Address are displayed$")
	public void verifyIfCustomerNameMasterAccountNumberAndCommunicationAddressAreDisplayed() throws Throwable {
		requestActions.verifyIfCustomerNameFieldIsDisplayed();
		requestActions.verifyIfMasterAccountFieldIsDisplayed();
		requestActions.verifyIfAddressFieldIsDisplayed();
	}
	
	@And("^Verify if Search Option is displayed to search Reference Number$")
	public void verifyIfSearchOptionIsDisplayedToSearchReferenceNumber() throws Throwable {
		requestActions.verifyIfSearchOptionIsDisplayed();
	}
	
	@And("^Verify if Export All button is displayed$")
	public void verifyIfExportAllButtonIsDisplayed() throws Throwable {
		requestActions.verifyIfExportAllButtonDisplayed();
	}
	
	@And("^Verify if Checkboxes, Reference Numbers, Service Addresses and View CTA button are displayed for each row$")
	public void verifyIfCheckboxesReferenceNumbersServiceAddressesAndViewCTAButtonAreDisplayedForEachRow() throws Throwable {
		requestActions.verifyIfCheckboxesAreDisplayedForEachRow();
		requestActions.verifyIfReferenceNumberIsDisplayedForEachRow();
		requestActions.verifyIfAddressIsDisplayedForEachRow();
		requestActions.verifyIfViewButtonIsDisplayedForEachRow();
	}
	
	@And("^User select any Checkbox and click on View CTA button$")
	public void userSelectAnyCheckboxAndClickOnViewCTAButton() throws Throwable {
		requestActions.clickOnAnyCheckboxOnReferenceNumbersPage();
		requestActions.clickOnViewButtonOnReferenceNumbersPage();
	}
	
	@And("^Verify if user is landed on Inventory Report page$")
	public void verifyIfUserIsLandedOnInventoryReportPage() throws Throwable {
		requestActions.verifyInventoryReportPageUrl();
		requestActions.verifyInventoryReportPageHeading();
	}
	
	@And("^Verify hyperlinks in the breadcrumb navigation on Inventory Report page$")
	public void verifyHyperlinksInBreadcrumbNavigationOnInventoryReportPage() throws Throwable {
		requestActions.verifyHyperlinksOnInventoryReportPage();
	}
	
	@And("^Verify hyperlinks in the breadcrumb navigation on Reference Numbers page$")
	public void verifyHyperlinksInBreadcrumbNavigationOnReferenceNumbersPage() throws Throwable {
		requestActions.verifyHyperlinksOnReferenceNumbersPage();
	}
	
	@And("^User clicks on Reference Numbers Breadcrumb link$")
	public void userClicksOnReferenceNumbersBreadcrumbLink() throws Throwable {
		requestActions.clickOnReferenceNumBreadcrumbOnInventoryPage();
	}
	
	@And("^User clicks on Account List Breadcrumb link$")
	public void userClicksOnAccountListBreadcrumbLink() throws Throwable {
		requestActions.clickOnAccountListBreadcrumbOnInventoryPage();
	}
	
	@And("^User clicks on Back button on Inventory Report page$")
	public void userClicksOnBackButtonOnInvetoryReportPage() throws Throwable {
		requestActions.clickOnBackButtonOnInvetoryReportPage();
	}
	
	@And("^User clicks on Back button on Reference Numbers Page$")
	public void userClicksOnBackButtonOnReferenceNumbersPage() throws Throwable {
		requestActions.clickOnBackButtonOnReferenceNumbersPage();
	}
	
	@And("^User clicks on Back button on Account selection page$")
	public void userClicksOnBackButtonOnPageAccountSelectionPage() throws Throwable {
		requestActions.clickOnBackButtonOnAccountListPage();
	}
	
	@And("^User clicks on Cancel button on Account selection page$")
	public void userClicksOnCancelButtonOnPageAccountSelectionPage() throws Throwable {
		requestActions.clickOnCancelButtonOnAccountListPage();
	}
	
	@And("^Verify if the Modal is displayed showing the number of records selected along with Export CTA Button$")
	public void verifyModalPopUpTextOnReferenceNumbersPage() throws Throwable {
		requestActions.clickOnCheckboxHeadingOnReferenceNumbersPage();
		requestActions.verifyModalPopUpOnReferenceNumbersPage();
	}
	
	@And("^User selects Multiple Rows in Reference Numbers page$")
	public void userSelectsMultipleRowsInReferenceNumbersPage() throws Throwable {
		requestActions.checkMultipleCheckboxesOnReferenceNumbersPage();
	}
	
	@And("^Verify if Pagination is displayed when the records are more than 25$")
	public void verifyPaginationIsDisplayedWhenRecordsAreMoreThan25() throws Throwable {
		
	}
	
	@And("^Verify the Pagination have First Prev Last options displaying$")
	public void verifyPaginationOptions() throws Throwable {
		requestActions.verifyPaginationOnReferenceNumbersPage();
	}
	
	@And("^Verify if Switch To Map View button is displayed$")
	public void verifyIfSwitchToMapViewButtonIsDisplayed() throws Throwable {
		requestActions.verifySwitchToMapViewIsDisplayed();
	}
	
	@And("^Verify if the Default view is Table view$")
	public void verifyIfDefaultViewIsTableView() throws Throwable {
		requestActions.verifyDefaultViewIsTableView();
	}
	
	@And("^Verify if Add Account and Select Account options are displayed$")
	public void verifyIfAddAccountAndSelectAccountOptionsAreDisplayed() throws Throwable {
		requestActions.verifyIfMasterAccountsHaveSelectAccountButton();
		requestActions.verifyIfReferenceAccountsHaveSelectAccountButton();
		requestActions.verifyIfAddAccountButtonIsDisplayed();
	}
	
	@And("^Verify if Address is displayed$")
	public void verifyIfAddressIsDisplayedOnAccountListsPage() throws Throwable {
		requestActions.verifyIfCommunicationAddressIsDisplayedOnAccountListsPage();
	}
	
	@And("^Verify Inventory Header fields$")
	public void verifyInventoryHeaderFields() throws Throwable {
		requestActions.verifyInventoryReportHeader();
	}

}