package com.nationalgrid.automation.nysl.steps;
import org.openqa.selenium.support.PageFactory;

import com.nationalgrid.automation.nysl.actions.ReportFormPageActions;
import com.nationalgrid.automation.nysl.base.BaseInitialiser;

import cucumber.api.java.en.Then;


public class ReportFormPageSteps extends BaseInitialiser {
	
	ReportFormPageActions requestActions = PageFactory.initElements(driver, ReportFormPageActions.class);
	
	@Then("^Verify Location fields in the Report Form$")
	public void verify_Location_fields_in_the_Report_Form() throws Throwable {
	    requestActions.verifyIfAddressFieldIsDisplayed();
	    requestActions.verifyIfPoleNumberIsDisplayed();
	}

	@Then("^Verfiy Outage fields in Report Form$")
	public void verfiy_Outage_fields_in_Report_Form() throws Throwable {
		requestActions.verifyIfLightTypeDropdownIsDisplayed();
		requestActions.verifyIfProblemTypeDropdownIsDisplayed();
	}

	@Then("^Verify if User can add Comments$")
	public void verify_if_User_can_add_Comments() throws Throwable {
	    requestActions.verifyIfUserCanAddComments("comment");
	}

	@Then("^Verify if Customer Info fields are displayed$")
	public void verify_if_Customer_Info_fields_are_displayed() throws Throwable {
	    requestActions.verifyIfContactNameInputIsDisplayed();
	    requestActions.verifyIfPhoneNumberInputIsDisplayed();
	    requestActions.verifyIfEmailAddressFieldIsDisplayed();
	}

	@Then("^Verify error message by giving Contact Name field as Empty and Fill others$")
	public void verify_error_message_by_giving_Contact_Name_field_as_Empty_and_Fill_others() throws Throwable {
		requestActions.enterContactName("");
	    requestActions.enterEmailAddress("vunnam.mounika@nationalgrid.com");
	    requestActions.enterPhoneNumber("9876543210");
	}

	@Then("^Verify error message by giving Phone Number field as Empty and Fill others$")
	public void verify_error_message_by_giving_Phone_Number_field_as_Empty_and_Fill_others() throws Throwable {
		requestActions.enterContactName("asdg");
	    requestActions.enterEmailAddress("vunnam.mounika@nationalgrid.com");
	    requestActions.enterPhoneNumber("");	    
	}

	@Then("^Verify error message by giving Email Address field as Empty and Fill others$")
	public void verify_error_message_by_giving_Email_Address_field_as_Empty_and_Fill_others() throws Throwable {
		requestActions.enterContactName("asdf");
	    requestActions.enterEmailAddress("");
	    requestActions.enterPhoneNumber("9876543210");	    
	}
	
	@Then("^User Fills all the details$")
	public void user_Fills_all_the_details() throws Throwable {
		requestActions.enterContactName("asdf");
	    requestActions.enterEmailAddress("vunnam.mounika@nationalgrid.com");
	    requestActions.enterPhoneNumber("9876543210");	    
	}

	@Then("^User clicks on Report Button$")
	public void user_clicks_on_Report_Button() throws Throwable {
	   requestActions.clickOnReportButton();
	}

	@Then("^Verify the Confirmation Message$")
	public void verify_the_Confirmation_Message() throws Throwable {
	    requestActions.verifyConfirmationMessage();
	}

	@Then("^Verify if Continue to Map is displayed$")
	public void verify_if_Continue_to_Map_is_displayed() throws Throwable {
	    requestActions.verifyIfContinueToMapIsDisplayed();
	}

	@Then("^User clicks on Continue to Map button$")
	public void user_clicks_on_Continue_to_Map_button() throws Throwable {
	    requestActions.clickOnContinueToMap();
	}

	@Then("^Verify if the User is redirected back to Map to Report another Outage if required$")
	public void verify_if_the_User_is_redirected_back_to_Map_to_Report_another_Outage_if_required() throws Throwable {
		requestActions.verifyOutageMapUrl();
	}
	
	@Then("^Verify if Modal dialog box to enter verification code$")
	public void verify_if_Modal_dialog_box_to_enter_verification_code() throws Throwable {
	   
	}

	@Then("^Enter verification code and check Report CTA button is active$")
	public void enter_verification_code_and_check_Report_CTA_button_is_active() throws Throwable {
	    
	}

	@Then("^Click on Report CTA button$")
	public void click_on_Report_CTA_button() throws Throwable {
	   
	}

	@Then("^Verify upon successful validation, outage is reported and confirmation is displayed$")
	public void verify_upon_successful_validation_outage_is_reported_and_confirmation_is_displayed() throws Throwable {
	   
	}
	
}