package com.nationalgrid.automation.nysl.actions;

import com.nationalgrid.automation.nysl.locators.LandingPageLocators;
import com.nationalgrid.automation.nysl.utilities.DriverUtility;

public class LandingPageActions extends LandingPageLocators {
	
	public void verifyLandingPage() throws Exception {
		DriverUtility.verifyElementIsDisplayed(landingPageHeading, "verify LandingPage", "verified LandingPage", "Unable to verify LandingPage");
	}
	
	public void clickOutageOptions() throws Exception {
		DriverUtility.clickElement(outageBtn, "Outage Button");
	}
	
	public void clickOnFAQ() throws Exception {
		DriverUtility.clickElement(faqBtn, "FAQ Button");
	}
	
}
