package com.nationalgrid.automation.nysl.actions;

import com.nationalgrid.automation.nysl.locators.ReportFormPageLocators;
import com.nationalgrid.automation.nysl.utilities.DriverUtility;

public class ReportFormPageActions extends ReportFormPageLocators {

	public void verifyIfAddressFieldIsDisplayed() throws Exception {
		DriverUtility.verifyElementIsDisplayed(addressInput, "verify addressLabel", "verified CounaddressLabelty", "Unable to verify the addressLabel");
	}
	
	public void verifyIfPoleNumberIsDisplayed () throws Exception {
		DriverUtility.verifyElementIsDisplayed(poleNumInput, "verify poleNumInput", "verified poleNumInput", "Unable to verify the poleNumInput");
	}
	
	public void verifyIfLightTypeDropdownIsDisplayed () throws Exception {
		String[] lightType = {"Street Light", "Private Area"};
		DriverUtility.verifyElementIsDisplayed(lightTypeDropdown, "verify lightTypeDropdown", "verified lightTypeDropdown", "Unable to verify the lightTypeDropdown");
		DriverUtility.getOptionsfromDropdown(poleNumInput, lightType);
	}
	
	public void verifyIfProblemTypeDropdownIsDisplayed () throws Exception {
		String[] probType = {"Light out", "Day Burner (Light on during day)", "Light noisy", "Light dim", "Light cycling on/off", 
				"Animal nest", "Exposed Wire", "Other (Explain in Comments)"};
		DriverUtility.verifyElementIsDisplayed(problemTypeDropdown, "verify problemTypeDropdown", "verified problemTypeDropdown", "Unable to verify the problemTypeDropdown");
		DriverUtility.getOptionsfromDropdown(poleNumInput, probType);
	}
	
	public void verifyIfBubbleIconIsDisplayed () throws Exception {
		DriverUtility.verifyElementIsDisplayed(poleInfoBubble, "verify poleInfoBubble", "verified poleInfoBubble", "Unable to verify the poleInfoBubble");
	}

	public void clickOnBubbleInfo () throws Exception {
		DriverUtility.clickElement(poleInfoBubble, "poleInfoBubble");
	}
	
	public void verifyIfExampleImagesAreDisplayed () throws Exception {
		DriverUtility.verifyElementIsDisplayed(polePopUp, "verify polePopUp", "verified polePopUp", "Unable to verify the polePopUp");
	}
	
	public void verifyIfContactNameInputIsDisplayed () throws Exception {
		DriverUtility.verifyElementIsDisplayed(contactNameInput, "verify contactNameInput", "verified contactNameInput", "Unable to verify the contactNameInput");
	}
	
	public void verifyIfPhoneNumberInputIsDisplayed () throws Exception {
		DriverUtility.verifyElementIsDisplayed(phoneNumberInput, "verify phoneNumberInput", "verified phoneNumberInput", "Unable to verify the phoneNumberInput");
	}
	
	public void verifyIfEmailAddressFieldIsDisplayed () throws Exception {
		DriverUtility.verifyElementIsDisplayed(emailInput, "verify emailInput", "verified emailInput", "Unable to verify the emailInput");
	}

	public void enterContactName (String input) throws Exception {
		DriverUtility.sendText(contactNameInput, input, "contactName");
	}
	
	public void enterPhoneNumber (String input) throws Exception {
		DriverUtility.sendText(phoneNumberInput, input, "phoneNumber");
	}
	
	public void enterEmailAddress (String input) throws Exception {
		DriverUtility.sendText(emailInput, input, "email");
	}
	
	public void verifyIfUserCanAddComments (String input) throws Exception {
		DriverUtility.sendText(commentsInput, input, "inputComment");
	}
	
	public void clickOnReportButton () throws Exception {
		DriverUtility.clickElement(reportBtn, "Report button");
	}
	
	public void verifyConfirmationMessage () throws Exception {
		DriverUtility.clickElement(cnfrmMesgText, "confirmation Message Text");
	}
	
	public void verifyIfContinueToMapIsDisplayed () throws Exception {
		DriverUtility.verifyElementIsDisplayed(continueToMapBtn, "verify continueToMap", "verified continueToMap", "Unable to verify the continueToMap");
	}
	
	public void clickOnContinueToMap () throws Exception {
		DriverUtility.clickElement(continueToMapBtn, "verify continueToMap");
	}
	
	public void verifyOutageMapUrl () throws Exception {
		DriverUtility.isURLContains("");
	}
	
}