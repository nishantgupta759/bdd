

import com.nationalgrid.automation.nysl.locators.ContactUsPageLocators;
import com.nationalgrid.automation.nysl.utilities.DriverUtility;

public class ContactUsPageActions extends ContactUsPageLocators {
	
	public void verifyEmailUsOption() throws Exception {
		DriverUtility.verifyElementIsDisplayed(emailUs, "User verfies emailUs",
				"User verfied emailUs", "User failed to verfiy emailUs");
	}
	
	public void verifyStreetLightOutage() throws Exception {
		DriverUtility.verifyElementIsDisplayed(streetLightOutage, "User verfies streetLightOutage",
				"User verfied streetLightOutage", "User failed to verfiy streetLightOutage");
	}
	
	public void clickOnStreetLightOutage() throws Exception {
		DriverUtility.clickElement(streetLightOutage, "streetLightOutage");
	}
	
	public void verifyStreetLightPageURL() throws Exception {
		DriverUtility.isURLContains("/Upstate-NY-Home/Streetlight-Portal/");
	}

}